# VidSaver — Admin Panel

A separate, secure Next.js (App Router) + TypeScript + Tailwind admin dashboard that reads the **same Supabase project** as the VidSaver User App.

```
 Users ──▶  VidSaver User App  ──┐                      anon key + user JWT (RLS)
                                 ├──▶  ONE Supabase project  (Auth · Postgres · RLS)
 Admins ──▶ VidSaver Admin Panel ┘                      admin JWT → is_admin() policies / RPC
                                                        service key (server only): auth.admin ops
```

## What is implemented

- Admin sign-in, protected routes, **server-side role verification** (`admin_roles` table), unauthorized page, POST-only sign-out
- Overview: real DB metrics, daily downloads, registration trend, provider usage, recent activity (zeros + empty states when there is no data)
- Users: search (name / email / ID), pagination, detail page with download stats, suspend / reactivate, super-admin-only deletion with typed confirmation
- Downloads: filters (status, provider, date range), pagination, failure inspection (host only — no full URLs)
- Analytics: consent-based page views, install-button clicks, browser-reported install signals (clearly labelled as signals, not exact installs)
- Monetization: provider status, placement inventory, verified-revenue entry + chart; shows **“Unavailable”** until real verified data exists
- Settings (feature flags, currency, provider toggles) and an append-only audit log

## Requirements

Node.js 20.9+ (22 recommended), npm, and the **same Supabase project** used by the User App.

## Installation

```bash
unzip VidSaver_Admin_Panel.zip && cd VidSaver_Admin_Panel
npm install
cp .env.example .env.local                       # fill in values
```

## Connect to the shared Supabase project

1. Use the **same** project URL, anon key and service-role key as the User App.
2. Apply the schema **once** (skip if you already applied it from the User App): Dashboard → SQL Editor → run `supabase/migrations/0001_init.sql`.
   The file is byte-identical in both projects — never run two different versions against one database.
3. Authentication → URL Configuration: add the admin site URL (e.g. `http://localhost:3001`, `https://admin.yourdomain.com`) to Redirect URLs if you later add email flows.

## Secure initial administrator creation

There is intentionally **no sign-up, no default admin and no hardcoded password**. Authorization lives in `public.admin_roles`, which has RLS with *no* write policies, so no user (and no profile edit) can grant it.

1. Create the account (User App sign-up, or Dashboard → Authentication → Users → Add user). Use a strong unique password; enable MFA on the Supabase dashboard account too.
2. Open `supabase/promote_first_admin.sql`, replace the email, and run it in the Supabase SQL Editor (privileged `postgres` role).
3. Sign in at the Admin Panel. Roles: `super_admin` (everything, incl. deleting users) and `admin` (read + safe actions).

Revoke access any time: `delete from public.admin_roles where user_id = (select id from auth.users where email = '…');`

## Environment variables

| Variable | Scope | Purpose |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | public | Shared project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | public | Anon key (RLS-protected) |
| `SUPABASE_SERVICE_ROLE_KEY` | **server only** | Read emails, ban/delete auth users — used only after admin verification |
| `ADSENSE_PUBLISHER_ID`, `ADSENSE_API_CREDENTIALS_JSON` | **server only**, optional | Presence flips the dashboard to “credentials present”. No sync is implemented, so no revenue is imported |

## Local testing

```bash
npm run dev -- -p 3001      # http://localhost:3001  (User App on 3000)
npm run typecheck && npm run lint
```

Manual checks:
1. Visit `/` while signed out → redirected to `/login`.
2. Sign in with a **non-admin** account → lands on `/unauthorized`; `/users`, `/downloads` etc. also redirect there.
3. Promote your account with the SQL script → dashboard loads.
4. Use the User App demo link to create a download job → see it under **Downloads** and in the Overview counts.

## Production build & deployment

```bash
npm run build && npm start
```

Deploy to Vercel as a **separate project** (ideally on a separate, non-guessable subdomain such as `admin.yourdomain.com`), add the env vars, and consider restricting access further (Vercel password protection / IP allow-list / Cloudflare Access).

## Security verification checklist

- [ ] Signed-out request to `/users` redirects to `/login` (middleware) and renders nothing sensitive
- [ ] Non-admin signed-in user cannot load any `(admin)` page (layout + page-level `requireAdmin()`)
- [ ] With a non-admin JWT, `select * from download_jobs` returns only that user’s rows; `select * from admin_roles` returns at most their own row; `insert into admin_roles …` is denied
- [ ] `rpc('admin_dashboard_stats')` as a non-admin returns `not authorized`
- [ ] `SUPABASE_SERVICE_ROLE_KEY` is not in any `NEXT_PUBLIC_*` variable and not in the client bundle (`grep -r service_role .next/static` returns nothing)
- [ ] Suspend / delete actions appear in **Audit log**
- [ ] Super-admin-only deletion is refused for plain `admin` accounts

## Connecting analytics and monetization

- **Analytics:** the User App writes consented events to `analytics_events`; this panel only reads them. Install numbers are *signals* — browsers (notably iOS Safari) do not reliably report installs. Per-day active users are not stored historically; extend the schema (e.g. a daily snapshot job) if you need that.
- **Monetization:** keep ads separate from the download flow. Implement a real provider sync (e.g. the AdSense Management API) in a server-only module that writes to `revenue_records` with `verified = true`; until then use the manual verified-entry form. Obtain consent before loading ad scripts and follow the network’s policies (no self-clicks, no deceptive placement).

## Limitations

- Charts are lightweight server-rendered SVG (no chart library) and show the last 7–90 days.
- Email search scans up to 1,000 auth users via the admin API — fine for early stages; add an indexed email mirror for larger user bases.
- Feature flags are stored in `app_settings`; the User App enforces only the ones it implements.
- Rate limiting for admin sign-in relies on Supabase Auth’s built-in limits; add edge/WAF rules for production.

## Verification status (honest report)

| Check | Result |
|---|---|
| Shared `0001_init.sql` applied to PostgreSQL 16 with Supabase `auth` stubbed | **Passed** |
| RLS tests (`supabase/tests/`): non-admin cannot read others' data, self-grant admin, call `admin_*` stats; admin can | **Passed** |
| Server-side admin gate reviewed (`requireAdmin` re-checks `admin_roles` in layout, pages and every server action) | **Reviewed** (no automated browser test) |
| Secret scan; service-role key is imported only by server modules | **Passed** |
| `npm install`, `tsc`, `next lint`, `next build` | **Blocked** — the build sandbox could not reach the npm registry. Run them yourself before deploying. |
| Live sign-in, admin promotion, and dashboards against a real Supabase project | **Not run** |
