# VidSaver shared schema & contracts

Both projects ship the **identical** `supabase/migrations/0001_init.sql`. Apply it **once** to the one shared Supabase project.
If you change the schema, change it in one new migration file and copy that file into **both** projects.

## Tables

| Table | Who can read | Who can write |
|---|---|---|
| `profiles` | owner; admins | owner (not `status`/`created_at`); admins |
| `admin_roles` | own row; super admins see all | **nobody via the API** (SQL Editor / service role only) |
| `download_jobs` | owner; admins | owner (own rows); server routes for guests |
| `provider_configs` | everyone (names/modes only) | admins |
| `app_settings` | public keys: everyone; all: admins | admins |
| `consent_records` | owner; admins | owner |
| `analytics_events` | admins | server (service role), only with consent |
| `audit_events` | admins | admins (own `actor_id` only); never updated/deleted |
| `ad_placements`, `revenue_records` | admins | admins |

## Shared enumerations

- `download_jobs.status`: `queued | analyzing | ready | downloading | completed | failed | unsupported`
- `profiles.status`: `active | suspended`
- `admin_roles.role`: `admin | super_admin`
- `analytics_events.event_type`: `page_view | install_button_click | install_prompt_accepted | app_installed | sign_up`

TypeScript mirror: `src/lib/types.ts` (identical in both projects).

## Server-side queries used by the Admin Panel

Admin pages run as the **signed-in admin** (anon key + their JWT), so RLS policies using `public.is_admin()` apply:

| Purpose | Query |
|---|---|
| Role check | `select role from admin_roles where user_id = auth.uid()` |
| Dashboard totals | `rpc admin_dashboard_stats()` |
| Daily downloads / signups / events | `rpc admin_daily_downloads(days)`, `admin_daily_signups(days)`, `admin_daily_events(days)` |
| Provider breakdown | `rpc admin_provider_usage()` |
| Users table | `select … from profiles order by created_at desc range(…)` |
| Downloads table | `select … from download_jobs` + filters on status/provider/date |
| Audit | `insert into audit_events (actor_id = auth.uid(), …)`; `select … order by created_at desc` |

The `admin_*` functions are `SECURITY DEFINER` but raise `not authorized` unless `is_admin()` is true, and return aggregates only.
The service-role key is used only for `auth.admin.*` operations (reading emails, banning/deleting auth users) after the caller has been verified.

## API contract (User App)

See the README table and `src/lib/types.ts` (`AnalyzeResponse`, `ApiError`).
