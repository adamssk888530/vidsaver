import { requireAdmin } from "@/lib/auth";
import { num, one } from "@/lib/format";
import { Alert, PageHeader, Panel, StatCard } from "@/components/ui";
import { BarChart, LineChart } from "@/components/charts";

export const metadata = { title: "Analytics" };

export default async function Analytics({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const range = [7, 14, 30, 90].includes(Number(one(sp.days))) ? Number(one(sp.days)) : 14;
  const { supabase } = await requireAdmin();

  const [events, downloads, signups, stats] = await Promise.all([
    supabase.rpc("admin_daily_events", { days: range }),
    supabase.rpc("admin_daily_downloads", { days: range }),
    supabase.rpc("admin_daily_signups", { days: range }),
    supabase.rpc("admin_dashboard_stats"),
  ]);
  const err = events.error ?? downloads.error ?? signups.error ?? stats.error;
  const ev = (events.data ?? []) as { day: string; page_views: number; install_clicks: number; install_signals: number }[];
  const dl = (downloads.data ?? []) as { day: string; total: number; completed: number; failed: number }[];
  const su = (signups.data ?? []) as { day: string; total: number }[];
  const s = (stats.data ?? {}) as Record<string, number>;
  const short = (d: string) => d.slice(5);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Website & PWA analytics"
        subtitle="Privacy-conscious: page and install events are recorded only for visitors who accepted analytics, and contain no IP address, user agent or full URL."
        actions={
          <form method="get" className="flex items-center gap-2">
            <label htmlFor="days" className="text-sm text-slate-300">Range</label>
            <select id="days" name="days" defaultValue={String(range)} className="input w-auto py-2">{[7, 14, 30, 90].map((d) => <option key={d} value={d}>{d} days</option>)}</select>
            <button className="btn-ghost">Apply</button>
          </form>
        }
      />
      {err && <Alert kind="error">Could not load analytics: {err.message}</Alert>}

      <Alert kind="info">
        <strong>About install numbers.</strong> “Install-button clicks” count taps on VidSaver’s Install button. “Install signals” count browser-reported
        events (prompt accepted / <code>appinstalled</code>). Not every browser exposes these (notably iOS Safari), and installs done through browser
        menus may not be observed — so these are indicators, not exact installation totals.
      </Alert>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Page views (30d)" value={num(s.page_views_30d)} hint="Consenting visitors only" />
        <StatCard label="Install-button clicks (30d)" value={num(s.install_clicks_30d)} />
        <StatCard label="Install signals (30d)" value={num(s.install_accepted_30d)} hint="Browser-reported; incomplete by nature" />
        <StatCard label="Active users (24h)" value={num(s.active_users_24h)} hint="Signed-in users" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Page views"><LineChart labels={ev.map((r) => short(r.day))} series={[{ name: "Page views", color: "#22d3ee", values: ev.map((r) => Number(r.page_views)) }]} empty="No consented page views in this range." /></Panel>
        <Panel title="Install clicks vs. install signals"><BarChart labels={ev.map((r) => short(r.day))} series={[{ name: "Button clicks", color: "#22d3ee", values: ev.map((r) => Number(r.install_clicks)) }, { name: "Install signals", color: "#a78bfa", values: ev.map((r) => Number(r.install_signals)) }]} empty="No install events in this range." /></Panel>
        <Panel title="Download requests"><BarChart labels={dl.map((r) => short(r.day))} series={[{ name: "Completed", color: "#22d3ee", values: dl.map((r) => Number(r.completed)) }, { name: "Failed", color: "#f87171", values: dl.map((r) => Number(r.failed)) }]} empty="No downloads in this range." /></Panel>
        <Panel title="New registrations"><LineChart labels={su.map((r) => short(r.day))} series={[{ name: "Registrations", color: "#22d3ee", values: su.map((r) => Number(r.total)) }]} empty="No registrations in this range." /></Panel>
      </div>
      <p className="text-xs text-slate-500">Daily active users per day are not stored historically; the “Active users (24h)” card reflects the current rolling window from each user’s last activity.</p>
    </div>
  );
}
