import { requireAdmin } from "@/lib/auth";
import { dt, pageParam } from "@/lib/format";
import { Alert, EmptyState, PageHeader, Pagination } from "@/components/ui";

export const metadata = { title: "Audit log" };
const PAGE_SIZE = 25;

export default async function Audit({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { supabase } = await requireAdmin();
  const page = pageParam(sp.page);
  const { data, count, error } = await supabase
    .from("audit_events")
    .select("id,actor_id,action,target_type,target_id,metadata,created_at", { count: "exact" })
    .order("created_at", { ascending: false })
    .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1);

  return (
    <div className="space-y-6">
      <PageHeader title="Admin activity log" subtitle="Append-only record of sensitive admin actions. Rows cannot be edited or deleted through the application." />
      {error && <Alert kind="error">Could not load the audit log: {error.message}</Alert>}
      {!error && (data ?? []).length === 0 ? (
        <EmptyState title="No admin actions recorded yet" text="Suspensions, deletions, setting changes and monetization edits are logged here." />
      ) : (
        <div className="card overflow-x-auto p-0 sm:p-0">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/10 text-xs uppercase text-slate-400"><tr><th className="p-3">When</th><th className="p-3">Admin</th><th className="p-3">Action</th><th className="p-3">Target</th><th className="p-3">Details</th></tr></thead>
            <tbody className="divide-y divide-white/10">
              {(data ?? []).map((r) => (
                <tr key={r.id} className="align-top">
                  <td className="p-3 text-slate-300">{dt(r.created_at)}</td>
                  <td className="p-3 font-mono text-xs text-slate-300">{r.actor_id?.slice(0, 8) ?? "—"}</td>
                  <td className="p-3">{r.action}</td>
                  <td className="p-3 text-xs text-slate-300">{r.target_type ?? "—"} <span className="font-mono">{r.target_id?.slice(0, 8) ?? ""}</span></td>
                  <td className="max-w-xs truncate p-3 font-mono text-xs text-slate-400" title={JSON.stringify(r.metadata)}>{Object.keys(r.metadata ?? {}).length ? JSON.stringify(r.metadata) : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} total={count ?? 0} pageSize={PAGE_SIZE} basePath="/audit" params={{}} />
    </div>
  );
}
