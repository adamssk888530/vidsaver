import { requireAdmin } from "@/lib/auth";
import { dt, num, one, pageParam } from "@/lib/format";
import { Alert, Badge, EmptyState, PageHeader, Pagination } from "@/components/ui";
import { JOB_STATUSES, type DownloadJob } from "@/lib/types";

export const metadata = { title: "Downloads" };
const PAGE_SIZE = 20;

export default async function Downloads({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { supabase } = await requireAdmin();

  const page = pageParam(sp.page);
  const status = one(sp.status);
  const provider = one(sp.provider);
  const from = one(sp.from);
  const to = one(sp.to);

  const isDate = (s: string) => /^\d{4}-\d{2}-\d{2}$/.test(s);
  let q = supabase
    .from("download_jobs")
    .select("id,user_id,anon_session_id,provider,source_host,format,quality,status,error_code,error_message,bytes,created_at,completed_at", { count: "exact" })
    .order("created_at", { ascending: false })
    .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1);
  if ((JOB_STATUSES as readonly string[]).includes(status)) q = q.eq("status", status);
  if (/^[a-z0-9_-]{2,40}$/.test(provider)) q = q.eq("provider", provider);
  if (isDate(from)) q = q.gte("created_at", `${from}T00:00:00Z`);
  if (isDate(to)) q = q.lte("created_at", `${to}T23:59:59Z`);

  const [{ data, count, error }, { data: provs }] = await Promise.all([q, supabase.from("provider_configs").select("provider").order("provider")]);
  const rows = (data ?? []) as DownloadJob[];

  const params: Record<string, string> = {};
  if (status) params.status = status;
  if (provider) params.provider = provider;
  if (isDate(from)) params.from = from;
  if (isDate(to)) params.to = to;

  return (
    <div className="space-y-6">
      <PageHeader title="Downloads" subtitle="Download jobs across all users. Links are never stored — only the source host, a hash, and outcome details." />

      <form method="get" className="card grid gap-3 sm:grid-cols-2 lg:grid-cols-5" aria-label="Filters">
        <div><label className="label" htmlFor="status">Status</label>
          <select id="status" name="status" defaultValue={status} className="input"><option value="">All</option>{JOB_STATUSES.map((s) => <option key={s}>{s}</option>)}</select></div>
        <div><label className="label" htmlFor="provider">Provider</label>
          <select id="provider" name="provider" defaultValue={provider} className="input"><option value="">All</option>{(provs ?? []).map((p) => <option key={p.provider}>{p.provider}</option>)}<option>unsupported</option></select></div>
        <div><label className="label" htmlFor="from">From</label><input id="from" name="from" type="date" defaultValue={isDate(from) ? from : ""} className="input" /></div>
        <div><label className="label" htmlFor="to">To</label><input id="to" name="to" type="date" defaultValue={isDate(to) ? to : ""} className="input" /></div>
        <div className="flex items-end gap-2"><button className="btn-primary flex-1">Apply</button><a href="/downloads" className="btn-ghost">Reset</a></div>
      </form>

      {error && <Alert kind="error">Could not load downloads: {error.message}</Alert>}

      {rows.length === 0 && !error ? (
        <EmptyState title="No downloads match" text="When users analyze or download links in the User App, the jobs appear here." />
      ) : (
        <div className="card overflow-x-auto p-0 sm:p-0">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/10 text-xs uppercase text-slate-400">
              <tr><th className="p-3">Job</th><th className="p-3">User</th><th className="p-3">Provider</th><th className="p-3">Format</th><th className="p-3">Status</th><th className="p-3">Created</th><th className="p-3">Outcome</th></tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {rows.map((r) => (
                <tr key={r.id} className="align-top">
                  <td className="p-3 font-mono text-xs text-slate-300" title={r.id}>{r.id.slice(0, 8)}</td>
                  <td className="p-3 font-mono text-xs text-slate-300">{r.user_id ? r.user_id.slice(0, 8) : <span className="text-slate-500">guest</span>}</td>
                  <td className="p-3">{r.provider}<div className="text-xs text-slate-500">{r.source_host ?? ""}</div></td>
                  <td className="p-3 text-slate-300">{r.format ?? "—"}{r.quality ? ` · ${r.quality}` : ""}</td>
                  <td className="p-3"><Badge>{r.status}</Badge></td>
                  <td className="p-3 text-slate-300">{dt(r.created_at)}</td>
                  <td className="p-3 text-xs text-slate-300">
                    {r.status === "completed" ? <>Done {dt(r.completed_at)}{r.bytes != null ? ` · ${num(r.bytes)} bytes` : ""}</> : r.error_code || r.error_message ? <details><summary className="cursor-pointer text-red-200">{r.error_code ?? "error"}</summary><p className="mt-1 max-w-xs">{r.error_message ?? "No details recorded."}</p></details> : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} total={count ?? 0} pageSize={PAGE_SIZE} basePath="/downloads" params={params} />
    </div>
  );
}
