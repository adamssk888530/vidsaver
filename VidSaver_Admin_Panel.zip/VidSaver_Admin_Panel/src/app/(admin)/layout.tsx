import { requireAdmin } from "@/lib/auth";
import { Shell } from "@/components/Shell";

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  // Server-side gate for every route in this group. Pages and server actions re-verify on their own.
  const { user, role } = await requireAdmin();
  return (
    <Shell email={user.email ?? "admin"} role={role}>
      {children}
    </Shell>
  );
}
