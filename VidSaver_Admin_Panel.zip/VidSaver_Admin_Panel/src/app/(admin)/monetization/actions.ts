"use server";
import { redirect } from "next/navigation";
import { logAudit, requireAdmin } from "@/lib/auth";
import { isUuid } from "@/lib/format";

const CURRENCIES = ["NGN", "USD", "EUR", "GBP"];
const done = (kind: "msg" | "err", text: string) => redirect(`/monetization?${kind}=${encodeURIComponent(text)}`);

export async function addPlacement(formData: FormData) {
  const ctx = await requireAdmin();
  const name = String(formData.get("name") ?? "").trim().slice(0, 80);
  const location = String(formData.get("location") ?? "").trim().slice(0, 120);
  const provider = String(formData.get("provider") ?? "").trim().slice(0, 60) || null;
  if (!name || !location) return done("err", "Name and location are required.");
  const { data, error } = await ctx.supabase.from("ad_placements").insert({ name, location, provider, enabled: false }).select("id").single();
  if (error) return done("err", "Could not add the placement.");
  await logAudit(ctx, "monetization.placement.add", { type: "ad_placement", id: data.id }, { name, location });
  done("msg", "Placement added (disabled until you enable it).");
}

export async function togglePlacement(formData: FormData) {
  const ctx = await requireAdmin();
  const id = String(formData.get("id") ?? "");
  const enabled = formData.get("enabled") === "true";
  if (!isUuid(id)) return done("err", "Invalid placement.");
  const { error } = await ctx.supabase.from("ad_placements").update({ enabled }).eq("id", id);
  if (error) return done("err", "Could not update the placement.");
  await logAudit(ctx, enabled ? "monetization.placement.enable" : "monetization.placement.disable", { type: "ad_placement", id });
  done("msg", "Placement updated.");
}

/** Manual entry of revenue the admin has verified against the provider's own report. Never auto-generated. */
export async function addRevenue(formData: FormData) {
  const ctx = await requireAdmin();
  const date = String(formData.get("period_date") ?? "");
  const amount = Number(formData.get("amount"));
  const currency = String(formData.get("currency") ?? "");
  const source = String(formData.get("source") ?? "").trim().slice(0, 80);
  const verified = formData.get("verified") === "on";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(amount) || amount < 0 || amount > 1e9 || !CURRENCIES.includes(currency) || !source) {
    return done("err", "Enter a valid date, amount, currency and source.");
  }
  if (!verified) return done("err", "Tick the box to confirm this figure was verified against the provider's report. Unverified figures are not recorded.");
  const { data, error } = await ctx.supabase
    .from("revenue_records")
    .insert({ period_date: date, amount: Math.round(amount * 100) / 100, currency, source, verified: true })
    .select("id")
    .single();
  if (error) return done("err", "Could not record the revenue.");
  await logAudit(ctx, "monetization.revenue.add", { type: "revenue_record", id: data.id }, { date, currency, source });
  done("msg", "Verified revenue recorded.");
}
