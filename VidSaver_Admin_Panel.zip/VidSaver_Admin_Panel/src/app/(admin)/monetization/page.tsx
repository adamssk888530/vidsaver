import { requireAdmin } from "@/lib/auth";
import { dt, money, one } from "@/lib/format";
import { Alert, Badge, EmptyState, PageHeader, Panel, StatCard } from "@/components/ui";
import { BarChart } from "@/components/charts";
import { addPlacement, addRevenue, togglePlacement } from "./actions";

export const metadata = { title: "Monetization" };
const CURRENCIES = ["NGN", "USD", "EUR", "GBP"];

export default async function Monetization({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { supabase } = await requireAdmin();

  const [{ data: settings }, placements, revenue] = await Promise.all([
    supabase.from("app_settings").select("value").eq("key", "currency").maybeSingle(),
    supabase.from("ad_placements").select("*").order("created_at", { ascending: false }),
    supabase.from("revenue_records").select("*").eq("verified", true).order("period_date", { ascending: false }).limit(500),
  ]);

  const defaultCur = ((settings?.value as { default?: string } | null)?.default ?? "NGN");
  const cur = CURRENCIES.includes(one(sp.currency)) ? one(sp.currency) : defaultCur;
  const records = (revenue.data ?? []).filter((r) => r.currency === cur);
  const total = records.reduce((s, r) => s + Number(r.amount), 0);

  // Group verified revenue by month (no currency conversion is ever performed).
  const byMonth = new Map<string, number>();
  records.forEach((r) => byMonth.set(String(r.period_date).slice(0, 7), (byMonth.get(String(r.period_date).slice(0, 7)) ?? 0) + Number(r.amount)));
  const months = [...byMonth.keys()].sort().slice(-12);

  const hasCreds = !!process.env.ADSENSE_PUBLISHER_ID;
  const hasVerified = (revenue.data ?? []).length > 0;

  return (
    <div className="space-y-6">
      <PageHeader title="Monetization" subtitle="Advertising stays separate from core download features. Nothing on this page is estimated or invented." />
      {one(sp.msg) && <Alert kind="ok">{one(sp.msg)}</Alert>}
      {one(sp.err) && <Alert kind="error">{one(sp.err)}</Alert>}

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Ad provider" value={hasCreds ? "Credentials present" : "Not connected"} hint={hasCreds ? "No provider API sync is implemented in this release, so revenue is not auto-imported." : "No provider credentials configured on the server."} />
        <StatCard label="Monetization status" value={(placements.data ?? []).some((p) => p.enabled) ? "Placements enabled" : "Inactive"} hint="Ads are not shown by the User App in this release." />
        <StatCard label={`Verified revenue (${cur})`} value={hasVerified ? money(total, cur) : "Unavailable"} hint={hasVerified ? "Sum of admin-verified entries" : "Shown only after a verified figure is recorded or a real provider sync exists."} />
      </div>

      <Panel title="Revenue history" note={`Verified entries only, in ${cur}. Different currencies are never converted or mixed.`}>
        <form method="get" className="mb-4 flex items-center gap-2"><label htmlFor="currency" className="text-sm text-slate-300">Currency</label>
          <select id="currency" name="currency" defaultValue={cur} className="input w-auto py-2">{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</select><button className="btn-ghost">View</button></form>
        <BarChart labels={months.map((m) => m.slice(2))} series={[{ name: `Revenue (${cur})`, color: "#22d3ee", values: months.map((m) => Math.round((byMonth.get(m) ?? 0) * 100) / 100) }]} empty="Revenue unavailable — no verified revenue has been recorded for this currency." />
      </Panel>

      <Panel title="Record verified revenue" note="Use only figures you have checked against your ad provider’s own dashboard or payment report. Unverified numbers are rejected.">
        <form action={addRevenue} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <div><label className="label" htmlFor="pd">Period date</label><input id="pd" name="period_date" type="date" required className="input" /></div>
          <div><label className="label" htmlFor="am">Amount</label><input id="am" name="amount" type="number" step="0.01" min="0" required className="input" /></div>
          <div><label className="label" htmlFor="cu">Currency</label><select id="cu" name="currency" defaultValue={cur} className="input">{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</select></div>
          <div><label className="label" htmlFor="so">Source</label><input id="so" name="source" required maxLength={80} placeholder="e.g. AdSense payment report" className="input" /></div>
          <div className="flex items-end"><button className="btn-primary w-full">Record</button></div>
          <label className="flex items-start gap-2 text-sm sm:col-span-2 lg:col-span-5"><input type="checkbox" name="verified" className="mt-1 accent-cyan-400" /> I verified this figure against the provider’s own report.</label>
        </form>
      </Panel>

      <Panel title="Ad placement inventory" note="Planned placements. Adding one does not display any ad.">
        {(placements.data ?? []).length === 0 ? <EmptyState title="No placements defined" text="Add the slots you plan to use, for example a banner on the History page." /> : (
          <ul className="divide-y divide-white/10">{(placements.data ?? []).map((p) => (
            <li key={p.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div><p className="font-medium">{p.name}</p><p className="text-xs text-slate-400">{p.location}{p.provider ? ` · ${p.provider}` : ""} · added {dt(p.created_at)}</p></div>
              <div className="flex items-center gap-3"><Badge tone={p.enabled ? "completed" : "failed"}>{p.enabled ? "enabled" : "disabled"}</Badge>
                <form action={togglePlacement}><input type="hidden" name="id" value={p.id} /><input type="hidden" name="enabled" value={String(!p.enabled)} /><button className="btn-ghost">{p.enabled ? "Disable" : "Enable"}</button></form></div>
            </li>))}</ul>
        )}
        <form action={addPlacement} className="mt-4 grid gap-3 sm:grid-cols-4">
          <input name="name" required maxLength={80} placeholder="Name" aria-label="Placement name" className="input" />
          <input name="location" required maxLength={120} placeholder="Location (e.g. history-page-banner)" aria-label="Placement location" className="input" />
          <input name="provider" maxLength={60} placeholder="Provider (optional)" aria-label="Provider" className="input" />
          <button className="btn-ghost">Add placement</button>
        </form>
      </Panel>

      <Panel title="Policy & privacy considerations">
        <ul className="list-disc space-y-1.5 pl-5 text-sm text-slate-300">
          <li>Obtain valid consent before loading ad scripts that set cookies or build profiles (GDPR/ePrivacy, NDPA); update the Privacy Policy first.</li>
          <li>Follow your ad network’s program policies. Never click your own ads, ask users to click, or place ads so they can be mistaken for download buttons.</li>
          <li>Keep ads out of the core download flow and clearly labeled as advertising.</li>
          <li>Connect a real provider (for example the AdSense Management API) before showing any automatically imported revenue.</li>
        </ul>
      </Panel>
    </div>
  );
}
