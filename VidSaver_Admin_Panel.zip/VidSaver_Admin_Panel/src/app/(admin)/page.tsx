import { requireAdmin } from "@/lib/auth";
import { num, pct, dt } from "@/lib/format";
import { Alert, Badge, EmptyState, PageHeader, Panel, StatCard } from "@/components/ui";
import { BarChart, HBars, LineChart } from "@/components/charts";
import type { DownloadJob } from "@/lib/types";

export const metadata = { title: "Overview" };

interface Stats {
  total_users: number;
  new_users_24h: number;
  active_users_24h: number;
  total_requests: number;
  completed: number;
  failed: number;
  page_views_30d: number;
  install_clicks_30d: number;
  install_accepted_30d: number;
}

export default async function Overview() {
  const { supabase } = await requireAdmin();

  const [stats, daily, signups, providers, recent] = await Promise.all([
    supabase.rpc("admin_dashboard_stats"),
    supabase.rpc("admin_daily_downloads", { days: 14 }),
    supabase.rpc("admin_daily_signups", { days: 14 }),
    supabase.rpc("admin_provider_usage"),
    supabase
      .from("download_jobs")
      .select("id,provider,status,format,created_at,error_code")
      .order("created_at", { ascending: false })
      .limit(8),
  ]);

  const failure = stats.error ?? daily.error ?? signups.error ?? providers.error ?? recent.error;
  const s = (stats.data ?? {}) as Partial<Stats>;
  const dayRows = (daily.data ?? []) as { day: string; total: number; completed: number; failed: number }[];
  const signupRows = (signups.data ?? []) as { day: string; total: number }[];
  const provRows = (providers.data ?? []) as { provider: string; total: number; completed: number; failed: number }[];
  const jobs = (recent.data ?? []) as Pick<DownloadJob, "id" | "provider" | "status" | "format" | "created_at" | "error_code">[];

  const finished = (s.completed ?? 0) + (s.failed ?? 0);
  const short = (d: string) => d.slice(5);

  return (
    <div className="space-y-6">
      <PageHeader title="Overview" subtitle="Live figures from the shared VidSaver database. Zeros mean no data has been recorded yet." />

      {failure && (
        <Alert kind="error">
          Could not load some metrics ({failure.message}). Confirm the shared migration <code>0001_init.sql</code> has been applied to this Supabase project.
        </Alert>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Registered users" value={num(s.total_users)} hint="All accounts ever created" />
        <StatCard label="New (24h)" value={num(s.new_users_24h)} hint="Registrations in the last 24 hours" />
        <StatCard label="Active users (24h)" value={num(s.active_users_24h)} hint="Signed-in users seen in the last 24h" />
        <StatCard label="Download requests" value={num(s.total_requests)} hint="All analyze/download attempts" />
        <StatCard label="Successful" value={num(s.completed)} tone="good" />
        <StatCard label="Failed" value={num(s.failed)} tone={s.failed ? "bad" : undefined} />
        <StatCard label="Success rate" value={pct(s.completed ?? 0, finished)} hint="Completed ÷ (completed + failed)" />
        <StatCard label="Consented page views (30d)" value={num(s.page_views_30d)} hint="Only visitors who accepted analytics" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Daily download activity" note="Last 14 days (UTC)">
          <BarChart
            labels={dayRows.map((r) => short(r.day))}
            series={[
              { name: "Completed", color: "#22d3ee", values: dayRows.map((r) => Number(r.completed)) },
              { name: "Failed", color: "#f87171", values: dayRows.map((r) => Number(r.failed)) },
            ]}
            empty="No download requests in the last 14 days."
          />
        </Panel>
        <Panel title="User registration trend" note="New accounts per day, last 14 days (UTC)">
          <LineChart labels={signupRows.map((r) => short(r.day))} series={[{ name: "Registrations", color: "#22d3ee", values: signupRows.map((r) => Number(r.total)) }]} empty="No registrations in the last 14 days." />
        </Panel>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Provider usage">
          <HBars rows={provRows.map((r) => ({ label: r.provider, value: Number(r.total), sub: `${num(r.completed)} ok · ${num(r.failed)} failed` }))} empty="No provider activity yet." />
        </Panel>
        <Panel title="What these numbers mean" note="Different measures — do not treat them as interchangeable.">
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between gap-4"><dt className="text-slate-300">Registered users</dt><dd className="text-right text-slate-400">accounts in the database</dd></div>
            <div className="flex justify-between gap-4"><dt className="text-slate-300">Active users</dt><dd className="text-right text-slate-400">signed-in users with recent activity</dd></div>
            <div className="flex justify-between gap-4"><dt className="text-slate-300">Website visitors</dt><dd className="text-right text-slate-400">not measured exactly; only consented page views</dd></div>
            <div className="flex justify-between gap-4"><dt className="text-slate-300">Install-button clicks (30d)</dt><dd className="text-right text-white">{num(s.install_clicks_30d)}</dd></div>
            <div className="flex justify-between gap-4"><dt className="text-slate-300">Install signals (30d)</dt><dd className="text-right text-white">{num(s.install_accepted_30d)}</dd></div>
          </dl>
          <p className="mt-3 text-xs text-slate-400">Install signals come from browser events that only some browsers fire (and only for consenting visitors). They are indicators, not an exact install count.</p>
        </Panel>
      </div>

      <Panel title="Recent activity">
        {jobs.length === 0 ? (
          <EmptyState title="No activity yet" text="Download requests will appear here as soon as users analyze links in the User App." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-xs uppercase text-slate-400"><tr><th className="py-2 pr-4">When</th><th className="pr-4">Provider</th><th className="pr-4">Format</th><th>Status</th></tr></thead>
              <tbody className="divide-y divide-white/10">
                {jobs.map((j) => (
                  <tr key={j.id}><td className="py-2 pr-4 text-slate-300">{dt(j.created_at)}</td><td className="pr-4">{j.provider}</td><td className="pr-4 text-slate-300">{j.format ?? "—"}</td><td><Badge>{j.status}</Badge></td></tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}
