"use server";
import { redirect } from "next/navigation";
import { logAudit, requireAdmin } from "@/lib/auth";

const CURRENCIES = ["NGN", "USD", "EUR", "GBP"];

export async function saveAppSettings(formData: FormData) {
  const ctx = await requireAdmin();
  const features = {
    guest_mode: formData.get("guest_mode") === "on",
    analytics: formData.get("analytics") === "on",
    signups: formData.get("signups") === "on",
  };
  const maintenance = { enabled: formData.get("maintenance") === "on" };
  const cur = String(formData.get("currency") ?? "NGN");
  const currency = { default: CURRENCIES.includes(cur) ? cur : "NGN", available: CURRENCIES };

  const stamp = { updated_by: ctx.user.id, updated_at: new Date().toISOString() };
  const { error } = await ctx.supabase.from("app_settings").upsert([
    { key: "features", value: features, is_public: true, ...stamp },
    { key: "maintenance", value: maintenance, is_public: true, ...stamp },
    { key: "currency", value: currency, is_public: true, ...stamp },
  ]);
  if (error) return redirect("/settings?err=" + encodeURIComponent("Could not save settings."));

  await logAudit(ctx, "settings.update", { type: "app_settings" }, { features, maintenance, currency: currency.default });
  redirect("/settings?msg=" + encodeURIComponent("Settings saved."));
}

export async function toggleProvider(formData: FormData) {
  const ctx = await requireAdmin();
  const provider = String(formData.get("provider") ?? "");
  const enabled = formData.get("enabled") === "true";
  if (!/^[a-z0-9_-]{2,40}$/.test(provider)) return redirect("/settings");

  const { error } = await ctx.supabase.from("provider_configs").update({ enabled, updated_at: new Date().toISOString() }).eq("provider", provider);
  if (error) return redirect("/settings?err=" + encodeURIComponent("Could not update the provider."));
  await logAudit(ctx, enabled ? "provider.enable" : "provider.disable", { type: "provider", id: provider });
  redirect("/settings?msg=" + encodeURIComponent(`Provider ${provider} ${enabled ? "enabled" : "disabled"}.`));
}
