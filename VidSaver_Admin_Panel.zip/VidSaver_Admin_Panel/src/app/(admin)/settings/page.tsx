import { requireAdmin } from "@/lib/auth";
import { one } from "@/lib/format";
import { Alert, Badge, PageHeader, Panel } from "@/components/ui";
import { saveAppSettings, toggleProvider } from "./actions";

export const metadata = { title: "Settings" };

export default async function Settings({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { supabase, role } = await requireAdmin();
  const [{ data: settings }, { data: providers, error }] = await Promise.all([
    supabase.from("app_settings").select("key,value"),
    supabase.from("provider_configs").select("*").order("provider"),
  ]);
  const get = (k: string) => (settings ?? []).find((s) => s.key === k)?.value ?? {};
  const features = get("features") as { guest_mode?: boolean; analytics?: boolean; signups?: boolean };
  const maintenance = get("maintenance") as { enabled?: boolean };
  const currency = get("currency") as { default?: string };

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" subtitle="Application settings and provider status. Secrets are never shown here — they live in server environment variables." />
      {one(sp.msg) && <Alert kind="ok">{one(sp.msg)}</Alert>}
      {one(sp.err) && <Alert kind="error">{one(sp.err)}</Alert>}
      {error && <Alert kind="error">Could not load providers: {error.message}</Alert>}

      <Panel title="Application settings" note="Stored in public.app_settings and logged in the audit trail.">
        <form action={saveAppSettings} className="space-y-4">
          {[
            ["guest_mode", "Guest mode (use without an account)", features.guest_mode ?? true],
            ["signups", "Allow new sign-ups", features.signups ?? true],
            ["analytics", "Collect consented analytics", features.analytics ?? true],
            ["maintenance", "Maintenance mode flag", maintenance.enabled ?? false],
          ].map(([name, label, on]) => (
            <label key={name as string} className="flex items-center gap-3 text-sm"><input type="checkbox" name={name as string} defaultChecked={on as boolean} className="h-4 w-4 accent-cyan-400" /> {label as string}</label>
          ))}
          <div className="max-w-xs"><label htmlFor="currency" className="label">Default currency</label>
            <select id="currency" name="currency" defaultValue={currency.default ?? "NGN"} className="input">{["NGN", "USD", "EUR", "GBP"].map((c) => <option key={c}>{c}</option>)}</select></div>
          <button className="btn-primary">Save settings</button>
          <p className="text-xs text-slate-500">These flags are stored for the apps to read. The User App enforces the ones it implements; extend its code before relying on a flag for enforcement.</p>
        </form>
      </Panel>

      <Panel title="Providers" note="A provider is usable only if its adapter exists in the User App code AND it is enabled here.">
        {(providers ?? []).length === 0 ? <p className="text-sm text-slate-400">No providers configured.</p> : (
          <ul className="divide-y divide-white/10">
            {(providers ?? []).map((p) => (
              <li key={p.provider} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <div>
                  <p className="font-medium">{p.display_name} <span className="font-mono text-xs text-slate-500">{p.provider}</span></p>
                  <p className="mt-0.5 flex flex-wrap gap-2 text-xs text-slate-400"><Badge tone={p.mode === "demo" ? "unsupported" : "completed"}>{p.mode}</Badge><Badge tone={p.enabled ? "completed" : "failed"}>{p.enabled ? "enabled" : "disabled"}</Badge>{p.supports_audio_only ? <Badge>audio-only</Badge> : null}</p>
                  {p.notes && <p className="mt-1 max-w-xl text-xs text-slate-500">{p.notes}</p>}
                </div>
                <form action={toggleProvider}>
                  <input type="hidden" name="provider" value={p.provider} />
                  <input type="hidden" name="enabled" value={String(!p.enabled)} />
                  <button className={p.enabled ? "btn-danger" : "btn-primary"}>{p.enabled ? "Disable" : "Enable"}</button>
                </form>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Panel title="Safe configuration">
        <ul className="list-disc space-y-1.5 pl-5 text-sm text-slate-300">
          <li>Keep <code>SUPABASE_SERVICE_ROLE_KEY</code> in server environment variables only (Vercel → Settings → Environment Variables).</li>
          <li>Rotate keys in Supabase if one is ever exposed, then redeploy both apps.</li>
          <li>Grant admin rights only through the documented SQL procedure in the README; there is intentionally no “make admin” button.</li>
          <li>You are signed in as <strong>{role.replace("_", " ")}</strong>.</li>
        </ul>
      </Panel>
    </div>
  );
}
