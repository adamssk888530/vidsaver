import Link from "next/link";
import { notFound } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { createServiceClient } from "@/lib/supabase/admin";
import { dt, isUuid, num, one, pct } from "@/lib/format";
import { Alert, Badge, EmptyState, PageHeader, Panel, StatCard } from "@/components/ui";
import { deleteUser, setUserStatus } from "../actions";
import type { DownloadJob, Profile } from "@/lib/types";

export const metadata = { title: "User detail" };

export default async function UserDetail({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  if (!isUuid(id)) notFound();
  const ctx = await requireAdmin();
  const { supabase } = ctx;

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", id).maybeSingle<Profile>();
  if (!profile) notFound();

  const svc = createServiceClient();
  const email = svc ? (await svc.auth.admin.getUserById(id)).data?.user?.email ?? null : null;

  const count = (status?: string) => {
    let q = supabase.from("download_jobs").select("id", { count: "exact", head: true }).eq("user_id", id);
    if (status) q = q.eq("status", status);
    return q;
  };
  const [total, ok, failed, jobs] = await Promise.all([
    count(),
    count("completed"),
    count("failed"),
    supabase
      .from("download_jobs")
      .select("id,provider,source_host,format,status,error_code,error_message,created_at")
      .eq("user_id", id)
      .order("created_at", { ascending: false })
      .limit(10),
  ]);
  const rows = (jobs.data ?? []) as Pick<DownloadJob, "id" | "provider" | "source_host" | "format" | "status" | "error_code" | "error_message" | "created_at">[];
  const msg = one(sp.msg);
  const err = one(sp.err);
  const isSelf = id === ctx.user.id;

  return (
    <div className="space-y-6">
      <PageHeader title={profile.display_name || "Unnamed user"} subtitle={`User ${id}`} actions={<Link href="/users" className="btn-ghost">← All users</Link>} />
      {msg && <Alert kind="ok">{msg}</Alert>}
      {err && <Alert kind="error">{err}</Alert>}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Requests" value={num(total.count)} />
        <StatCard label="Completed" value={num(ok.count)} tone="good" />
        <StatCard label="Failed" value={num(failed.count)} tone={failed.count ? "bad" : undefined} />
        <StatCard label="Success rate" value={pct(ok.count ?? 0, (ok.count ?? 0) + (failed.count ?? 0))} />
      </div>

      <Panel title="Account">
        <dl className="grid gap-4 text-sm sm:grid-cols-2">
          <div><dt className="text-xs uppercase text-slate-400">Email</dt><dd className="mt-1 break-all">{email ?? "Hidden (service key not configured)"}</dd></div>
          <div><dt className="text-xs uppercase text-slate-400">Status</dt><dd className="mt-1"><Badge>{profile.status}</Badge></dd></div>
          <div><dt className="text-xs uppercase text-slate-400">Registered</dt><dd className="mt-1">{dt(profile.created_at)}</dd></div>
          <div><dt className="text-xs uppercase text-slate-400">Last activity</dt><dd className="mt-1">{dt(profile.last_seen_at)}</dd></div>
          <div><dt className="text-xs uppercase text-slate-400">Analytics consent</dt><dd className="mt-1">{profile.analytics_consent ? "Granted" : "Not granted"}</dd></div>
          <div><dt className="text-xs uppercase text-slate-400">History retention</dt><dd className="mt-1">{profile.history_retention_days} days</dd></div>
        </dl>
      </Panel>

      <Panel title="Recent downloads">
        {rows.length === 0 ? <EmptyState title="No downloads yet" /> : (
          <div className="overflow-x-auto"><table className="w-full text-left text-sm">
            <thead className="text-xs uppercase text-slate-400"><tr><th className="py-2 pr-4">When</th><th className="pr-4">Provider</th><th className="pr-4">Format</th><th>Status</th></tr></thead>
            <tbody className="divide-y divide-white/10">{rows.map((j) => (
              <tr key={j.id}><td className="py-2 pr-4 text-slate-300">{dt(j.created_at)}</td><td className="pr-4">{j.provider}<div className="text-xs text-slate-500">{j.source_host}</div></td><td className="pr-4 text-slate-300">{j.format ?? "—"}</td><td><Badge>{j.status}</Badge>{j.error_code ? <span className="ml-2 text-xs text-red-200">{j.error_code}</span> : null}</td></tr>
            ))}</tbody></table></div>
        )}
      </Panel>

      <Panel title="Account controls" note="Server-authorized and recorded in the audit log.">
        {isSelf ? <p className="text-sm text-slate-400">This is your own account; controls are disabled.</p> : (
          <div className="space-y-5">
            <form action={setUserStatus} className="flex flex-wrap items-center gap-3">
              <input type="hidden" name="id" value={id} />
              <input type="hidden" name="status" value={profile.status === "active" ? "suspended" : "active"} />
              {profile.status === "active" ? (
                <>
                  <button className="btn-danger">Suspend account</button>
                  <span className="text-xs text-slate-400">Blocks sign-in and downloads until reactivated.</span>
                </>
              ) : (
                <>
                  <button className="btn-primary">Reactivate account</button>
                  <span className="text-xs text-slate-400">Restores sign-in and downloads.</span>
                </>
              )}
            </form>
            {ctx.role === "super_admin" && (
              <form action={deleteUser} className="rounded-xl border border-red-400/30 p-4">
                <p className="text-sm font-semibold text-red-200">Delete account permanently</p>
                <p className="mt-1 text-xs text-slate-400">Removes the user, their profile and download history. This cannot be undone. Type <code>DELETE</code> to confirm.</p>
                <input type="hidden" name="id" value={id} />
                <div className="mt-3 flex flex-wrap gap-2"><input name="confirm" autoComplete="off" required pattern="DELETE" aria-label="Type DELETE to confirm" className="input w-40" placeholder="DELETE" /><button className="btn-danger">Delete user</button></div>
              </form>
            )}
          </div>
        )}
      </Panel>
    </div>
  );
}
