"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { logAudit, requireAdmin, requireSuperAdmin } from "@/lib/auth";
import { createServiceClient } from "@/lib/supabase/admin";
import { isUuid } from "@/lib/format";

const back = (id: string, kind: "msg" | "err", text: string) =>
  redirect(`/users/${id}?${kind}=${encodeURIComponent(text)}`);

async function targetIsAdmin(userId: string) {
  const svc = createServiceClient();
  if (!svc) return false;
  const { data } = await svc.from("admin_roles").select("user_id").eq("user_id", userId).maybeSingle();
  return !!data;
}

/** Suspend or reactivate. Re-verifies the caller's admin role on every invocation. */
export async function setUserStatus(formData: FormData) {
  const ctx = await requireAdmin();
  const id = String(formData.get("id") ?? "");
  const next = String(formData.get("status") ?? "");
  if (!isUuid(id) || (next !== "active" && next !== "suspended")) return redirect("/users");

  if (id === ctx.user.id) return back(id, "err", "You cannot change your own account status.");
  if ((await targetIsAdmin(id)) && ctx.role !== "super_admin") return back(id, "err", "Only a super admin can change another administrator.");

  const { error } = await ctx.supabase.from("profiles").update({ status: next }).eq("id", id);
  if (error) return back(id, "err", "Could not update the account status.");

  // Also block/unblock sign-in at the auth layer when the service key is available.
  const svc = createServiceClient();
  if (svc) await svc.auth.admin.updateUserById(id, { ban_duration: next === "suspended" ? "876000h" : "none" });

  await logAudit(ctx, next === "suspended" ? "user.suspend" : "user.reactivate", { type: "user", id });
  revalidatePath(`/users/${id}`);
  back(id, "msg", next === "suspended" ? "Account suspended." : "Account reactivated.");
}

/** Permanent deletion: super admins only, requires typing DELETE. */
export async function deleteUser(formData: FormData) {
  const ctx = await requireSuperAdmin();
  const id = String(formData.get("id") ?? "");
  const confirm = String(formData.get("confirm") ?? "");
  if (!isUuid(id)) return redirect("/users");
  if (confirm !== "DELETE") return back(id, "err", 'Type DELETE exactly to confirm.');
  if (id === ctx.user.id) return back(id, "err", "You cannot delete your own account here.");
  if (await targetIsAdmin(id)) return back(id, "err", "Remove the administrator role before deleting this account.");

  const svc = createServiceClient();
  if (!svc) return back(id, "err", "Deletion requires SUPABASE_SERVICE_ROLE_KEY on the server.");

  await svc.from("download_jobs").delete().eq("user_id", id);
  const { error } = await svc.auth.admin.deleteUser(id);
  if (error) return back(id, "err", "Could not delete the user.");

  await logAudit(ctx, "user.delete", { type: "user", id });
  redirect("/users");
}
