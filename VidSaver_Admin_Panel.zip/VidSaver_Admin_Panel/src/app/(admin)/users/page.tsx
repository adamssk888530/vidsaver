import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { createServiceClient } from "@/lib/supabase/admin";
import { dt, isUuid, likeSafe, one, pageParam } from "@/lib/format";
import { Alert, Badge, EmptyState, PageHeader, Pagination } from "@/components/ui";
import type { Profile } from "@/lib/types";

export const metadata = { title: "Users" };
const PAGE_SIZE = 20;

export default async function Users({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const { supabase } = await requireAdmin();
  const page = pageParam(sp.page);
  const search = one(sp.q).trim().slice(0, 100);
  const status = one(sp.status);
  const service = createServiceClient();

  let q = supabase
    .from("profiles")
    .select("id,display_name,status,last_seen_at,created_at,preferred_currency", { count: "exact" })
    .order("created_at", { ascending: false })
    .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1);
  if (status === "active" || status === "suspended") q = q.eq("status", status);

  let note: string | null = null;
  if (search) {
    if (isUuid(search)) q = q.eq("id", search);
    else if (search.includes("@")) {
      // Email lives in auth.users, which only the service role can read. Look up matching ids server-side.
      if (!service) {
        note = "Email search needs SUPABASE_SERVICE_ROLE_KEY on the server.";
      } else {
        const ids: string[] = [];
        for (let p = 1; p <= 5 && ids.length < 50; p++) {
          const { data } = await service.auth.admin.listUsers({ page: p, perPage: 200 });
          const users = data?.users ?? [];
          users.forEach((u) => u.email?.toLowerCase().includes(search.toLowerCase()) && ids.push(u.id));
          if (users.length < 200) break;
        }
        q = ids.length ? q.in("id", ids) : q.eq("id", "00000000-0000-0000-0000-000000000000");
      }
    } else {
      const s = likeSafe(search);
      if (s) q = q.ilike("display_name", `%${s}%`);
    }
  }

  const { data, count, error } = await q;
  const rows = (data ?? []) as Pick<Profile, "id" | "display_name" | "status" | "last_seen_at" | "created_at" | "preferred_currency">[];

  // Emails for just this page (authorized admins only; never sent to the browser beyond this table).
  const emails = new Map<string, string>();
  if (service) {
    await Promise.all(
      rows.map(async (r) => {
        const { data: u } = await service.auth.admin.getUserById(r.id);
        if (u?.user?.email) emails.set(r.id, u.user.email);
      })
    );
  }

  const params: Record<string, string> = {};
  if (search) params.q = search;
  if (status) params.status = status;

  return (
    <div className="space-y-6">
      <PageHeader title="Users" subtitle="Registered accounts. Search by name, email or user ID." />
      <form method="get" className="card flex flex-wrap items-end gap-3">
        <div className="min-w-[14rem] flex-1"><label htmlFor="q" className="label">Search</label><input id="q" name="q" defaultValue={search} placeholder="Name, email or user ID" className="input" /></div>
        <div><label htmlFor="status" className="label">Status</label><select id="status" name="status" defaultValue={status} className="input"><option value="">All</option><option>active</option><option>suspended</option></select></div>
        <button className="btn-primary">Search</button>
        <Link href="/users" className="btn-ghost">Reset</Link>
      </form>

      {!service && <Alert kind="info">Emails are hidden because <code>SUPABASE_SERVICE_ROLE_KEY</code> is not configured on the server.</Alert>}
      {note && <Alert kind="info">{note}</Alert>}
      {error && <Alert kind="error">Could not load users: {error.message}</Alert>}

      {rows.length === 0 && !error ? (
        <EmptyState title="No users found" text={search ? "Try a different search." : "Accounts appear here after people sign up in the User App."} />
      ) : (
        <div className="card overflow-x-auto p-0 sm:p-0">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/10 text-xs uppercase text-slate-400"><tr><th className="p-3">User</th><th className="p-3">Email</th><th className="p-3">Registered</th><th className="p-3">Last activity</th><th className="p-3">Status</th></tr></thead>
            <tbody className="divide-y divide-white/10">
              {rows.map((r) => (
                <tr key={r.id}>
                  <td className="p-3"><Link className="text-cyan-300 hover:underline" href={`/users/${r.id}`}>{r.display_name || "—"}</Link><div className="font-mono text-xs text-slate-500">{r.id.slice(0, 8)}</div></td>
                  <td className="p-3 text-slate-300">{emails.get(r.id) ?? "—"}</td>
                  <td className="p-3 text-slate-300">{dt(r.created_at)}</td>
                  <td className="p-3 text-slate-300">{dt(r.last_seen_at)}</td>
                  <td className="p-3"><Badge>{r.status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} total={count ?? 0} pageSize={PAGE_SIZE} basePath="/users" params={params} />
    </div>
  );
}
