import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "VidSaver Admin", template: "%s · VidSaver Admin" },
  robots: { index: false, follow: false },
  icons: { icon: "/icons/icon-192.png" },
};
export const viewport: Viewport = { themeColor: "#081126", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
