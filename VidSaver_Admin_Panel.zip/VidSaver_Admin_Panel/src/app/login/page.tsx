"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Logo } from "@/components/Logo";
import { createClient } from "@/lib/supabase/client";

export default function AdminLogin() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { error } = await createClient().auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) {
      setError(error.status === 429 ? "Too many attempts. Please wait and try again." : "Incorrect email or password.");
      return;
    }
    // Role is verified server-side by the (admin) layout; non-admins land on /unauthorized.
    router.push("/");
    router.refresh();
  };

  return (
    <main className="grid min-h-screen place-items-center p-4">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex flex-col items-center gap-1"><Logo /><p className="text-xs uppercase tracking-widest text-cyan-300">Administration</p></div>
        <form onSubmit={submit} className="card space-y-4">
          <h1 className="text-xl font-bold">Admin sign in</h1>
          <div><label htmlFor="email" className="label">Email</label><input id="email" type="email" required autoComplete="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          <div><label htmlFor="password" className="label">Password</label><input id="password" type="password" required autoComplete="current-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          {error && <div className="alert-error" role="alert">{error}</div>}
          <button className="btn-primary w-full" disabled={busy}>{busy && <Loader2 size={16} className="animate-spin" aria-hidden="true" />} Sign in</button>
          <p className="text-xs text-slate-400">Access is limited to authorized administrators. Attempts are rate-limited and sign-ins are logged by Supabase Auth.</p>
        </form>
      </div>
    </main>
  );
}
