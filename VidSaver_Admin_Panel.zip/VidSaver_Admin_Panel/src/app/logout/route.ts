import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

/** POST-only sign out (prevents logout via cross-site GET/image requests). */
export async function POST(request: Request) {
  const supabase = await createClient();
  await supabase.auth.signOut();
  return NextResponse.redirect(new URL("/login", request.url), { status: 303 });
}
