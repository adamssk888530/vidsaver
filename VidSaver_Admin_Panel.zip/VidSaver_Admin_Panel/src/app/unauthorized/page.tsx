import { ShieldAlert } from "lucide-react";

export const metadata = { title: "Unauthorized" };

export default function Unauthorized() {
  return (
    <main className="grid min-h-screen place-items-center p-4 text-center">
      <div className="card max-w-md">
        <ShieldAlert size={36} className="mx-auto text-red-300" aria-hidden="true" />
        <h1 className="mt-3 text-2xl font-bold">Access denied</h1>
        <p className="mt-2 text-sm text-slate-300">
          This account is signed in but is not an authorized administrator. If you believe this is a mistake, ask an existing
          super admin to grant access.
        </p>
        <form action="/logout" method="post" className="mt-5">
          <button className="btn-primary">Sign out</button>
        </form>
      </div>
    </main>
  );
}
