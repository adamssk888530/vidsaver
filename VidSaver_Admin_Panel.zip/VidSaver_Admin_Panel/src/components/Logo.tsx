export function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
      <rect width="48" height="48" rx="12" fill="#081126" />
      <circle cx="24" cy="24" r="16" fill="none" stroke="#22d3ee" strokeWidth="2.5" />
      <path d="M24 13v14m0 0-6-6m6 6 6-6" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M16 34h16" stroke="#22d3ee" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function Logo() {
  return (
    <span className="inline-flex items-center gap-2.5">
      <LogoMark />
      <span className="text-xl font-extrabold tracking-tight text-white">
        Vid<span className="text-cyan-400">Saver</span>
      </span>
    </span>
  );
}
