"use client";
import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Users, Download, BarChart3, Wallet, Settings, ScrollText, Menu, X, ShieldCheck, LogOut } from "lucide-react";
import { Logo } from "./Logo";

const NAV = [
  { href: "/", label: "Overview", Icon: LayoutDashboard },
  { href: "/users", label: "Users", Icon: Users },
  { href: "/downloads", label: "Downloads", Icon: Download },
  { href: "/analytics", label: "Analytics", Icon: BarChart3 },
  { href: "/monetization", label: "Monetization", Icon: Wallet },
  { href: "/settings", label: "Settings", Icon: Settings },
  { href: "/audit", label: "Audit log", Icon: ScrollText },
];

export function Shell({ email, role, children }: { email: string; role: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  const links = (
    <ul className="space-y-1">
      {NAV.map(({ href, label, Icon }) => {
        const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
        return (
          <li key={href}>
            <Link
              href={href}
              onClick={() => setOpen(false)}
              aria-current={active ? "page" : undefined}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm ${active ? "bg-cyan-400/15 text-cyan-300" : "text-slate-300 hover:bg-white/5"}`}
            >
              <Icon size={18} aria-hidden="true" /> {label}
            </Link>
          </li>
        );
      })}
    </ul>
  );

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[16rem_1fr]">
      <aside className="hidden border-r border-white/10 bg-navy-950/80 p-4 lg:block">
        <div className="mb-6 px-2"><Logo /><p className="mt-1 text-xs uppercase tracking-widest text-cyan-300">Admin</p></div>
        <nav aria-label="Admin">{links}</nav>
      </aside>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-navy-900 p-4">
            <div className="mb-6 flex items-center justify-between px-2">
              <Logo />
              <button className="rounded-lg p-2 hover:bg-white/10" onClick={() => setOpen(false)} aria-label="Close menu"><X size={20} /></button>
            </div>
            <nav aria-label="Admin">{links}</nav>
          </aside>
        </div>
      )}

      <div className="min-w-0">
        <header className="sticky top-0 z-40 flex h-16 items-center justify-between gap-3 border-b border-white/10 bg-navy-950/80 px-4 backdrop-blur">
          <button className="rounded-lg p-2 hover:bg-white/10 lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu"><Menu size={22} /></button>
          <div className="hidden items-center gap-2 text-sm text-slate-300 lg:flex"><ShieldCheck size={16} className="text-cyan-300" aria-hidden="true" /> Restricted area · every action is logged</div>
          <div className="ml-auto flex items-center gap-3">
            <div className="text-right text-xs leading-tight"><p className="max-w-[10rem] truncate text-slate-200 sm:max-w-xs">{email}</p><p className="text-cyan-300">{role.replace("_", " ")}</p></div>
            <form action="/logout" method="post">
              <button className="btn-ghost" aria-label="Sign out"><LogOut size={16} aria-hidden="true" /> <span className="hidden sm:inline">Sign out</span></button>
            </form>
          </div>
        </header>
        <main className="mx-auto max-w-6xl p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
