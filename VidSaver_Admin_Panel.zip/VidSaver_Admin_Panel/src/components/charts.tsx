// Dependency-free SVG charts (server-renderable). Values come straight from database queries.

interface Series {
  name: string;
  color: string;
  values: number[];
}

const W = 640;
const H = 220;
const P = { l: 36, r: 12, t: 12, b: 28 };

function scale(max: number) {
  const m = Math.max(1, max);
  const step = Math.pow(10, Math.floor(Math.log10(m)));
  const nice = Math.ceil(m / step) * step;
  return nice;
}

export function LineChart({ labels, series, empty = "No data in this range yet." }: { labels: string[]; series: Series[]; empty?: string }) {
  const all = series.flatMap((s) => s.values);
  if (!labels.length || all.every((v) => v === 0)) return <ChartEmpty text={empty} />;
  const max = scale(Math.max(...all));
  const iw = W - P.l - P.r;
  const ih = H - P.t - P.b;
  const x = (i: number) => P.l + (labels.length === 1 ? iw / 2 : (i / (labels.length - 1)) * iw);
  const y = (v: number) => P.t + ih - (v / max) * ih;
  const ticks = [0, 0.5, 1].map((t) => Math.round(max * t));
  const every = Math.ceil(labels.length / 7);

  return (
    <figure>
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label={`Line chart of ${series.map((s) => s.name).join(", ")}`}>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={P.l} x2={W - P.r} y1={y(t)} y2={y(t)} stroke="rgba(255,255,255,.08)" />
            <text x={P.l - 6} y={y(t) + 4} textAnchor="end" fontSize="11" fill="#94a3b8">{t}</text>
          </g>
        ))}
        {series.map((s) => (
          <g key={s.name}>
            <polyline fill="none" stroke={s.color} strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" points={s.values.map((v, i) => `${x(i)},${y(v)}`).join(" ")} />
            {s.values.map((v, i) => (
              <circle key={i} cx={x(i)} cy={y(v)} r="3" fill={s.color}><title>{`${s.name} · ${labels[i]}: ${v}`}</title></circle>
            ))}
          </g>
        ))}
        {labels.map((l, i) =>
          i % every === 0 ? (
            <text key={l + i} x={x(i)} y={H - 8} textAnchor="middle" fontSize="11" fill="#94a3b8">{l}</text>
          ) : null
        )}
      </svg>
      <Legend series={series} />
    </figure>
  );
}

export function BarChart({ labels, series, empty = "No data in this range yet." }: { labels: string[]; series: Series[]; empty?: string }) {
  const all = series.flatMap((s) => s.values);
  if (!labels.length || all.every((v) => v === 0)) return <ChartEmpty text={empty} />;
  const max = scale(Math.max(...all));
  const iw = W - P.l - P.r;
  const ih = H - P.t - P.b;
  const group = iw / labels.length;
  const bw = Math.max(3, (group * 0.7) / series.length);
  const y = (v: number) => P.t + ih - (v / max) * ih;
  const ticks = [0, 0.5, 1].map((t) => Math.round(max * t));
  const every = Math.ceil(labels.length / 7);

  return (
    <figure>
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label={`Bar chart of ${series.map((s) => s.name).join(", ")}`}>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={P.l} x2={W - P.r} y1={y(t)} y2={y(t)} stroke="rgba(255,255,255,.08)" />
            <text x={P.l - 6} y={y(t) + 4} textAnchor="end" fontSize="11" fill="#94a3b8">{t}</text>
          </g>
        ))}
        {labels.map((l, i) => (
          <g key={l + i}>
            {series.map((s, k) => {
              const v = s.values[i] ?? 0;
              const bx = P.l + i * group + (group - bw * series.length) / 2 + k * bw;
              return (
                <rect key={s.name} x={bx} y={y(v)} width={bw - 1} height={Math.max(0, P.t + ih - y(v))} rx="2" fill={s.color}>
                  <title>{`${s.name} · ${l}: ${v}`}</title>
                </rect>
              );
            })}
            {i % every === 0 && <text x={P.l + i * group + group / 2} y={H - 8} textAnchor="middle" fontSize="11" fill="#94a3b8">{l}</text>}
          </g>
        ))}
      </svg>
      <Legend series={series} />
    </figure>
  );
}

export function HBars({ rows, empty = "Nothing to show yet." }: { rows: { label: string; value: number; sub?: string }[]; empty?: string }) {
  if (!rows.length) return <ChartEmpty text={empty} />;
  const max = Math.max(1, ...rows.map((r) => r.value));
  return (
    <ul className="space-y-3">
      {rows.map((r) => (
        <li key={r.label}>
          <div className="mb-1 flex justify-between text-sm"><span className="text-slate-200">{r.label}</span><span className="text-slate-400">{r.value.toLocaleString()}{r.sub ? ` · ${r.sub}` : ""}</span></div>
          <div className="h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-cyan-400" style={{ width: `${(r.value / max) * 100}%` }} /></div>
        </li>
      ))}
    </ul>
  );
}

function Legend({ series }: { series: Series[] }) {
  if (series.length < 2) return null;
  return (
    <figcaption className="mt-2 flex flex-wrap gap-4 text-xs text-slate-300">
      {series.map((s) => (
        <span key={s.name} className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: s.color }} />{s.name}</span>
      ))}
    </figcaption>
  );
}

export function ChartEmpty({ text }: { text: string }) {
  return <div className="grid h-40 place-items-center rounded-xl border border-dashed border-white/15 text-center text-sm text-slate-400">{text}</div>;
}
