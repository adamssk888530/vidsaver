import Link from "next/link";
import type { ReactNode } from "react";

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold text-white sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 max-w-2xl text-sm text-slate-400">{subtitle}</p>}
      </div>
      {actions}
    </div>
  );
}

export function StatCard({ label, value, hint, tone }: { label: string; value: string; hint?: string; tone?: "good" | "bad" }) {
  return (
    <div className="card">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{label}</p>
      <p className={`mt-2 text-3xl font-bold ${tone === "bad" ? "text-red-300" : tone === "good" ? "text-emerald-300" : "text-white"}`}>{value}</p>
      {hint && <p className="mt-1 text-xs text-slate-400">{hint}</p>}
    </div>
  );
}

export function Panel({ title, note, children }: { title: string; note?: string; children: ReactNode }) {
  return (
    <section className="card">
      <h2 className="text-base font-semibold text-white">{title}</h2>
      {note && <p className="mb-3 mt-0.5 text-xs text-slate-400">{note}</p>}
      <div className={note ? "" : "mt-3"}>{children}</div>
    </section>
  );
}

export function EmptyState({ title, text }: { title: string; text?: string }) {
  return (
    <div className="grid place-items-center rounded-xl border border-dashed border-white/15 px-4 py-10 text-center">
      <p className="font-medium text-slate-200">{title}</p>
      {text && <p className="mt-1 max-w-md text-sm text-slate-400">{text}</p>}
    </div>
  );
}

const tones: Record<string, string> = {
  completed: "border-emerald-400/40 bg-emerald-500/10 text-emerald-200",
  active: "border-emerald-400/40 bg-emerald-500/10 text-emerald-200",
  failed: "border-red-400/40 bg-red-500/10 text-red-200",
  suspended: "border-red-400/40 bg-red-500/10 text-red-200",
  unsupported: "border-amber-300/40 bg-amber-400/10 text-amber-100",
  downloading: "border-cyan-400/40 bg-cyan-400/10 text-cyan-100",
};
export function Badge({ children, tone }: { children: ReactNode; tone?: string }) {
  return <span className={`inline-block rounded-full border px-2.5 py-0.5 text-xs ${tones[tone ?? String(children)] ?? "border-white/20 bg-white/5 text-slate-200"}`}>{children}</span>;
}

export function Alert({ kind, children }: { kind: "error" | "ok" | "info"; children: ReactNode }) {
  return <div role={kind === "error" ? "alert" : "status"} className={kind === "error" ? "alert-error" : kind === "ok" ? "alert-ok" : "alert-info"}>{children}</div>;
}

/** Server-rendered pagination using plain links (works without JS). */
export function Pagination({ page, total, pageSize, basePath, params }: { page: number; total: number; pageSize: number; basePath: string; params: Record<string, string> }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const href = (p: number) => {
    const sp = new URLSearchParams({ ...params, page: String(p) });
    return `${basePath}?${sp.toString()}`;
  };
  return (
    <nav aria-label="Pagination" className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm">
      <span className="text-slate-400">{total.toLocaleString()} result{total === 1 ? "" : "s"} · page {Math.min(page, pages)} of {pages}</span>
      <span className="flex gap-2">
        {page > 1 ? <Link className="btn-ghost" href={href(page - 1)}>Previous</Link> : <span className="btn-ghost opacity-40" aria-disabled="true">Previous</span>}
        {page < pages ? <Link className="btn-ghost" href={href(page + 1)}>Next</Link> : <span className="btn-ghost opacity-40" aria-disabled="true">Next</span>}
      </span>
    </nav>
  );
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`animate-pulse rounded-xl bg-white/10 ${className}`} aria-hidden="true" />;
}

export function PageSkeleton() {
  return (
    <div role="status" aria-label="Loading">
      <Skeleton className="mb-6 h-9 w-64" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-28" />)}</div>
      <Skeleton className="mt-6 h-64" />
    </div>
  );
}
