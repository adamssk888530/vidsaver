import "server-only";
import { redirect } from "next/navigation";
import type { SupabaseClient, User } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";

export interface AdminContext {
  user: User;
  role: "admin" | "super_admin";
  supabase: SupabaseClient;
}

/**
 * Server-side role verification. Authorization comes from the `admin_roles` table, which end users
 * cannot write (no INSERT/UPDATE/DELETE policy exists). It does NOT come from profile fields,
 * JWT metadata the user can edit, cookies, or client state.
 * Call this at the top of EVERY admin page, route handler and server action.
 */
export async function requireAdmin(): Promise<AdminContext> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser(); // validates the JWT with Supabase Auth
  if (!user) redirect("/login");

  const { data: row } = await supabase.from("admin_roles").select("role").eq("user_id", user.id).maybeSingle();
  if (!row || (row.role !== "admin" && row.role !== "super_admin")) redirect("/unauthorized");

  return { user, role: row.role, supabase };
}

export async function requireSuperAdmin(): Promise<AdminContext> {
  const ctx = await requireAdmin();
  if (ctx.role !== "super_admin") redirect("/unauthorized");
  return ctx;
}

/** Writes an audit row attributed to the verified admin (RLS enforces actor_id = auth.uid()). */
export async function logAudit(
  ctx: AdminContext,
  action: string,
  target?: { type?: string; id?: string },
  metadata: Record<string, unknown> = {}
) {
  await ctx.supabase.from("audit_events").insert({
    actor_id: ctx.user.id,
    action,
    target_type: target?.type ?? null,
    target_id: target?.id ?? null,
    metadata,
  });
}
