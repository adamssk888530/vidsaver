export const num = (n: number | null | undefined) => (n ?? 0).toLocaleString("en-US");

export const pct = (part: number, whole: number) => (whole > 0 ? `${((part / whole) * 100).toFixed(1)}%` : "—");

export const dt = (s: string | null | undefined) => (s ? new Date(s).toLocaleString("en-GB", { timeZone: "UTC", dateStyle: "medium", timeStyle: "short" }) + " UTC" : "—");

export function money(amount: number, currency: string) {
  try {
    return new Intl.NumberFormat(currency === "NGN" ? "en-NG" : "en-US", { style: "currency", currency }).format(amount);
  } catch {
    return `${amount.toFixed(2)} ${currency}`;
  }
}

/** Parses ?page= safely. */
export function pageParam(v: string | string[] | undefined, max = 100_000) {
  const n = Number(Array.isArray(v) ? v[0] : v);
  return Number.isFinite(n) && n >= 1 ? Math.min(Math.floor(n), max) : 1;
}

export const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";

/** Escapes characters that are special in PostgREST `ilike`/`or` filters. */
export const likeSafe = (s: string) => s.replace(/[%_,()*\\]/g, " ").trim().slice(0, 80);

export const isUuid = (s: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
