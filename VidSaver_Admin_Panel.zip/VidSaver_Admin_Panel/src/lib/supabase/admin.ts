import "server-only";
import { createClient } from "@supabase/supabase-js";

/**
 * SERVER-ONLY service-role client (bypasses RLS). Call ONLY after `requireAdmin()` / `requireSuperAdmin()`.
 * Scope of use: auth.admin APIs (read emails, ban/delete users). Routine data reads go through the
 * signed-in admin's own session, where RLS + is_admin() policies apply (least privilege).
 */
export function createServiceClient() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!key || !url) return null;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}
