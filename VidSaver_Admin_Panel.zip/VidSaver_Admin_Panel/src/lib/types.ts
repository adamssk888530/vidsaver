// Shared contract — keep identical in the Admin Panel (src/lib/types.ts).

export const JOB_STATUSES = [
  "queued",
  "analyzing",
  "ready",
  "downloading",
  "completed",
  "failed",
  "unsupported",
] as const;
export type JobStatus = (typeof JOB_STATUSES)[number];

export const PROFILE_STATUSES = ["active", "suspended"] as const;
export type ProfileStatus = (typeof PROFILE_STATUSES)[number];

export const ANALYTICS_EVENTS = [
  "page_view",
  "install_button_click",
  "install_prompt_accepted",
  "app_installed",
  "sign_up",
] as const;
export type AnalyticsEventType = (typeof ANALYTICS_EVENTS)[number];

export interface Profile {
  id: string;
  display_name: string | null;
  status: ProfileStatus;
  preferred_currency: string;
  history_retention_days: number;
  analytics_consent: boolean;
  last_seen_at: string | null;
  created_at: string;
}

export interface DownloadJob {
  id: string;
  user_id: string | null;
  anon_session_id: string | null;
  provider: string;
  source_host: string | null;
  source_hash: string | null;
  format: string | null;
  quality: string | null;
  status: JobStatus;
  error_code: string | null;
  error_message: string | null;
  bytes: number | null;
  created_at: string;
  completed_at: string | null;
}

// ── API contracts ──
export interface MediaFormat {
  id: string;
  label: string;
  kind: "video" | "audio";
  container: string;
  quality: string;
  approxBytes?: number;
}

/** POST /api/analyze  body: { url: string } */
export interface AnalyzeResponse {
  ok: true;
  provider: { id: string; name: string; mode: "demo" | "production" };
  media: {
    title: string;
    durationSec?: number;
    thumbnailUrl?: string | null;
    previewAllowed: boolean;
    formats: MediaFormat[];
    audioOnlySupported: boolean;
  };
  /** Signed, short-lived token authorizing GET /api/download?token=…&format=… */
  token: string;
  jobId: string | null;
}

export interface ApiError {
  ok: false;
  code:
    | "invalid_url"
    | "unsupported_provider"
    | "provider_unavailable"
    | "rate_limited"
    | "unauthorized"
    | "bad_request"
    | "server_error";
  message: string;
}
