-- VidSaver shared schema (v1). Used by BOTH the User App and the Admin Panel.
-- Apply once to the single shared Supabase project (SQL Editor or `supabase db push`).
-- Keep this file byte-identical in both projects (supabase/migrations/0001_init.sql).

create extension if not exists "pgcrypto";

-- ───────────────────────── Enumerated values (shared contract) ─────────────────────────
-- download_jobs.status : queued | analyzing | ready | downloading | completed | failed | unsupported
-- profiles.status      : active | suspended
-- admin_roles.role     : admin | super_admin
-- analytics_events.event_type :
--   page_view | install_button_click | install_prompt_accepted | app_installed | sign_up

-- ───────────────────────── Tables ─────────────────────────

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text check (char_length(display_name) <= 80),
  status text not null default 'active' check (status in ('active','suspended')),
  preferred_currency text not null default 'NGN' check (preferred_currency ~ '^[A-Z]{3}$'),
  history_retention_days int not null default 90 check (history_retention_days between 1 and 365),
  analytics_consent boolean not null default false,
  last_seen_at timestamptz,
  created_at timestamptz not null default now()
);

-- Roles live in their own table. Users have NO write policy on it, so a profile
-- edit can never grant admin rights. Promotion is a privileged SQL procedure (see Admin README).
create table if not exists public.admin_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'admin' check (role in ('admin','super_admin')),
  granted_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.provider_configs (
  provider text primary key check (provider ~ '^[a-z0-9_-]{2,40}$'),
  display_name text not null,
  mode text not null default 'demo' check (mode in ('demo','production')),
  enabled boolean not null default false,
  supports_audio_only boolean not null default false,
  notes text,
  updated_at timestamptz not null default now()
);

create table if not exists public.download_jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  anon_session_id text check (anon_session_id is null or char_length(anon_session_id) <= 64),
  provider text not null,
  source_host text,                -- hostname only; full URLs are never stored
  source_hash text,                -- sha256 of the normalized URL, for de-duplication only
  format text,
  quality text,
  status text not null default 'queued'
    check (status in ('queued','analyzing','ready','downloading','completed','failed','unsupported')),
  error_code text,
  error_message text check (error_message is null or char_length(error_message) <= 300),
  bytes bigint,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);
create index if not exists download_jobs_user_created_idx on public.download_jobs (user_id, created_at desc);
create index if not exists download_jobs_created_idx on public.download_jobs (created_at desc);
create index if not exists download_jobs_status_idx on public.download_jobs (status, created_at desc);
create index if not exists download_jobs_provider_idx on public.download_jobs (provider, created_at desc);

create table if not exists public.app_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  is_public boolean not null default false,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

create table if not exists public.consent_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  anon_session_id text,
  consent_type text not null check (consent_type in ('analytics','terms','privacy')),
  granted boolean not null,
  created_at timestamptz not null default now()
);
create index if not exists consent_user_idx on public.consent_records (user_id, created_at desc);

create table if not exists public.analytics_events (
  id bigint generated always as identity primary key,
  event_type text not null
    check (event_type in ('page_view','install_button_click','install_prompt_accepted','app_installed','sign_up')),
  anon_session_id text,
  path text check (path is null or char_length(path) <= 200),
  created_at timestamptz not null default now()
);
create index if not exists analytics_type_created_idx on public.analytics_events (event_type, created_at desc);

create table if not exists public.audit_events (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_type text,
  target_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_created_idx on public.audit_events (created_at desc);

-- Monetization (admin-only). Rows exist only when a human enters verified data
-- or a real provider sync writes them. Nothing is seeded.
create table if not exists public.ad_placements (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  location text not null,
  provider text,
  enabled boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.revenue_records (
  id uuid primary key default gen_random_uuid(),
  period_date date not null,
  amount numeric(14,2) not null check (amount >= 0),
  currency text not null check (currency ~ '^[A-Z]{3}$'),
  source text not null,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists revenue_period_idx on public.revenue_records (period_date desc);

-- ───────────────────────── Helper functions ─────────────────────────

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admin_roles where user_id = auth.uid());
$$;

create or replace function public.is_super_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admin_roles where user_id = auth.uid() and role = 'super_admin');
$$;

revoke all on function public.is_admin() from public;
revoke all on function public.is_super_admin() from public;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.is_super_admin() to authenticated;

-- New auth user -> profile row
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, nullif(left(coalesce(new.raw_user_meta_data->>'display_name',''), 80), ''))
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Users may not change their own status or created_at. Only service role / admins can.
create or replace function public.protect_profile_columns()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.role() = 'service_role' or public.is_admin() then
    return new;
  end if;
  if new.status is distinct from old.status or new.created_at is distinct from old.created_at then
    raise exception 'status and created_at cannot be changed by the account holder';
  end if;
  return new;
end $$;

drop trigger if exists protect_profile_columns_trg on public.profiles;
create trigger protect_profile_columns_trg
  before update on public.profiles
  for each row execute function public.protect_profile_columns();

-- Retention: delete finished history older than each user's chosen window.
create or replace function public.purge_expired_history()
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  delete from public.download_jobs j
  using public.profiles p
  where j.user_id = p.id
    and j.created_at < now() - make_interval(days => p.history_retention_days);
  get diagnostics n = row_count;
  delete from public.download_jobs where user_id is null and created_at < now() - interval '30 days';
  delete from public.analytics_events where created_at < now() - interval '180 days';
  return n;
end $$;
revoke all on function public.purge_expired_history() from public, anon, authenticated;
-- Schedule with pg_cron or a Supabase scheduled function (see README).

-- ───────────────────────── Admin reporting functions ─────────────────────────
-- SECURITY DEFINER but gated by is_admin(): they return aggregates only.

create or replace function public.admin_dashboard_stats()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not authorized' using errcode = '42501'; end if;
  return jsonb_build_object(
    'total_users',        (select count(*) from public.profiles),
    'new_users_24h',      (select count(*) from public.profiles where created_at > now() - interval '24 hours'),
    'active_users_24h',   (select count(*) from public.profiles where last_seen_at > now() - interval '24 hours'),
    'total_requests',     (select count(*) from public.download_jobs),
    'completed',          (select count(*) from public.download_jobs where status = 'completed'),
    'failed',             (select count(*) from public.download_jobs where status = 'failed'),
    'page_views_30d',     (select count(*) from public.analytics_events where event_type = 'page_view' and created_at > now() - interval '30 days'),
    'install_clicks_30d', (select count(*) from public.analytics_events where event_type = 'install_button_click' and created_at > now() - interval '30 days'),
    'install_accepted_30d',(select count(*) from public.analytics_events where event_type in ('install_prompt_accepted','app_installed') and created_at > now() - interval '30 days')
  );
end $$;

create or replace function public.admin_daily_downloads(days int default 14)
returns table (day date, total bigint, completed bigint, failed bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not authorized' using errcode = '42501'; end if;
  return query
  select d::date,
         count(j.id),
         count(j.id) filter (where j.status = 'completed'),
         count(j.id) filter (where j.status = 'failed')
  from generate_series(current_date - (least(greatest(days,1),90) - 1), current_date, interval '1 day') d
  left join public.download_jobs j on j.created_at::date = d::date
  group by d order by d;
end $$;

create or replace function public.admin_daily_signups(days int default 14)
returns table (day date, total bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not authorized' using errcode = '42501'; end if;
  return query
  select d::date, count(p.id)
  from generate_series(current_date - (least(greatest(days,1),90) - 1), current_date, interval '1 day') d
  left join public.profiles p on p.created_at::date = d::date
  group by d order by d;
end $$;

create or replace function public.admin_provider_usage()
returns table (provider text, total bigint, completed bigint, failed bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not authorized' using errcode = '42501'; end if;
  return query
  select j.provider, count(*), count(*) filter (where j.status='completed'), count(*) filter (where j.status='failed')
  from public.download_jobs j group by j.provider order by count(*) desc;
end $$;

create or replace function public.admin_daily_events(days int default 14)
returns table (day date, page_views bigint, install_clicks bigint, install_signals bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not authorized' using errcode = '42501'; end if;
  return query
  select d::date,
         count(e.id) filter (where e.event_type = 'page_view'),
         count(e.id) filter (where e.event_type = 'install_button_click'),
         count(e.id) filter (where e.event_type in ('install_prompt_accepted','app_installed'))
  from generate_series(current_date - (least(greatest(days,1),90) - 1), current_date, interval '1 day') d
  left join public.analytics_events e on e.created_at::date = d::date
  group by d order by d;
end $$;

revoke all on function public.admin_dashboard_stats() from public, anon;
revoke all on function public.admin_daily_downloads(int) from public, anon;
revoke all on function public.admin_daily_signups(int) from public, anon;
revoke all on function public.admin_provider_usage() from public, anon;
revoke all on function public.admin_daily_events(int) from public, anon;
grant execute on function public.admin_dashboard_stats() to authenticated;
grant execute on function public.admin_daily_downloads(int) to authenticated;
grant execute on function public.admin_daily_signups(int) to authenticated;
grant execute on function public.admin_provider_usage() to authenticated;
grant execute on function public.admin_daily_events(int) to authenticated;

-- ───────────────────────── Row Level Security ─────────────────────────

alter table public.profiles          enable row level security;
alter table public.admin_roles       enable row level security;
alter table public.provider_configs  enable row level security;
alter table public.download_jobs     enable row level security;
alter table public.app_settings      enable row level security;
alter table public.consent_records   enable row level security;
alter table public.analytics_events  enable row level security;
alter table public.audit_events      enable row level security;
alter table public.ad_placements     enable row level security;
alter table public.revenue_records   enable row level security;

-- profiles
create policy profiles_select_own   on public.profiles for select to authenticated using (id = auth.uid());
create policy profiles_select_admin on public.profiles for select to authenticated using (public.is_admin());
create policy profiles_update_own   on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_update_admin on public.profiles for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- admin_roles: a user may read only their own row (so the app can check). No insert/update/delete policies at all.
create policy admin_roles_select_own on public.admin_roles for select to authenticated using (user_id = auth.uid());
create policy admin_roles_select_all_super on public.admin_roles for select to authenticated using (public.is_super_admin());

-- provider_configs: readable by everyone signed in or not (needed to show supported providers); admin-managed.
create policy provider_configs_read  on public.provider_configs for select to anon, authenticated using (true);
create policy provider_configs_write on public.provider_configs for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- download_jobs
create policy jobs_select_own   on public.download_jobs for select to authenticated using (user_id = auth.uid());
create policy jobs_insert_own   on public.download_jobs for insert to authenticated with check (user_id = auth.uid());
create policy jobs_update_own   on public.download_jobs for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy jobs_delete_own   on public.download_jobs for delete to authenticated using (user_id = auth.uid());
create policy jobs_select_admin on public.download_jobs for select to authenticated using (public.is_admin());

-- app_settings: public keys readable by all; admin manages.
create policy settings_read_public on public.app_settings for select to anon, authenticated using (is_public = true);
create policy settings_read_admin  on public.app_settings for select to authenticated using (public.is_admin());
create policy settings_write_admin on public.app_settings for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- consent_records
create policy consent_select_own on public.consent_records for select to authenticated using (user_id = auth.uid());
create policy consent_insert_own on public.consent_records for insert to authenticated with check (user_id = auth.uid());
create policy consent_select_admin on public.consent_records for select to authenticated using (public.is_admin());

-- analytics_events: written server-side (service role) only after consent; admins read.
create policy analytics_select_admin on public.analytics_events for select to authenticated using (public.is_admin());

-- audit_events: admins read; admins insert rows attributed to themselves; nobody updates/deletes.
create policy audit_select_admin on public.audit_events for select to authenticated using (public.is_admin());
create policy audit_insert_admin on public.audit_events for insert to authenticated with check (public.is_admin() and actor_id = auth.uid());

-- monetization: admin only
create policy ad_placements_admin   on public.ad_placements   for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy revenue_records_admin on public.revenue_records  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ───────────────────────── Seed (non-secret configuration only) ─────────────────────────
insert into public.provider_configs (provider, display_name, mode, enabled, supports_audio_only, notes)
values ('demo', 'Demo Provider (sample media)', 'demo', true, false,
        'Serves a bundled, royalty-free sample clip to demonstrate the adapter interface. Not a real source.')
on conflict (provider) do nothing;

insert into public.app_settings (key, value, is_public) values
  ('currency', '{"default":"NGN","available":["NGN","USD","EUR","GBP"]}', true),
  ('features', '{"guest_mode":true,"analytics":true,"signups":true}', true),
  ('maintenance', '{"enabled":false}', true)
on conflict (key) do nothing;
