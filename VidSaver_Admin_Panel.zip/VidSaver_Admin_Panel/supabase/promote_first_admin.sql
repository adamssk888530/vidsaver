-- ─────────────────────────────────────────────────────────────────────────────
-- Promote the FIRST administrator (privileged, one-time procedure)
--
-- Run this in the Supabase Dashboard → SQL Editor (runs as the `postgres` role).
-- It cannot be executed by app users: the `admin_roles` table has RLS enabled with NO
-- insert/update/delete policies, and the anon/authenticated roles have no way around that.
--
-- Steps:
--   1. Create the person's account normally (sign up in the User App, or Dashboard →
--      Authentication → Users → Add user) and confirm their email. Use a strong, unique password + enable MFA where possible.
--   2. Replace the email below and run this script.
--   3. Sign in at the Admin Panel with that account.
-- ─────────────────────────────────────────────────────────────────────────────

insert into public.admin_roles (user_id, role)
select id, 'super_admin'
from auth.users
where email = 'REPLACE_WITH_ADMIN_EMAIL@example.com'
on conflict (user_id) do update set role = excluded.role;

-- Verify (should return exactly one row):
select u.email, r.role, r.created_at
from public.admin_roles r join auth.users u on u.id = r.user_id;

-- Later, to add a regular admin (cannot delete users or manage other admins):
--   insert into public.admin_roles (user_id, role) select id, 'admin' from auth.users where email = 'colleague@example.com';
-- To revoke access:
--   delete from public.admin_roles where user_id = (select id from auth.users where email = 'colleague@example.com');
