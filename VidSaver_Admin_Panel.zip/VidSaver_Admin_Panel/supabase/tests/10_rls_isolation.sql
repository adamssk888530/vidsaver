\set ON_ERROR_STOP off
grant usage on schema public to anon, authenticated, service_role;
grant all on all tables in schema public to anon, authenticated, service_role;
grant execute on all functions in schema public to service_role;
insert into auth.users(id,email) values
 ('11111111-1111-1111-1111-111111111111','alice@x.test'),
 ('22222222-2222-2222-2222-222222222222','bob@x.test'),
 ('33333333-3333-3333-3333-333333333333','admin@x.test') on conflict do nothing;
insert into public.profiles(id) values ('11111111-1111-1111-1111-111111111111'),('22222222-2222-2222-2222-222222222222'),('33333333-3333-3333-3333-333333333333') on conflict do nothing;
insert into public.admin_roles(user_id,role) values ('33333333-3333-3333-3333-333333333333','admin') on conflict do nothing;
insert into public.download_jobs(user_id,provider,status) values
 ('11111111-1111-1111-1111-111111111111','demo','completed'),
 ('22222222-2222-2222-2222-222222222222','demo','failed');

\echo '=== T1 alice sees only her own jobs (expect 1)'
set role authenticated; select set_config('request.jwt.claim.sub','11111111-1111-1111-1111-111111111111',false), set_config('request.jwt.claim.role','authenticated',false) \gset
select count(*) from public.download_jobs;
\echo '=== T2 alice sees only her profile (expect 1)'
select count(*) from public.profiles;
\echo '=== T3 alice inserts job as bob (expect RLS violation)'
insert into public.download_jobs(user_id,provider) values ('22222222-2222-2222-2222-222222222222','demo');
\echo '=== T4 alice changes own status to suspended->active trick: set created_at (expect exception)'
update public.profiles set created_at = now() - interval '5 years' where id = '11111111-1111-1111-1111-111111111111';
\echo '=== T5 alice self-grants admin (expect RLS violation)'
insert into public.admin_roles(user_id,role) values ('11111111-1111-1111-1111-111111111111','super_admin');
\echo '=== T6 alice reads admin_roles (expect 0 rows)'
select count(*) from public.admin_roles;
\echo '=== T7 alice calls admin_dashboard_stats (expect error/empty, not data)'
select * from public.admin_dashboard_stats();
\echo '=== T8 alice reads audit/analytics/revenue (expect 0 each)'
select (select count(*) from public.audit_events) a,(select count(*) from public.analytics_events) b,(select count(*) from public.revenue_records) c;
\echo '=== T9 alice updates bob job (expect 0 rows)'
update public.download_jobs set status='completed' where user_id='22222222-2222-2222-2222-222222222222';
\echo '=== T10 alice deletes own job (expect DELETE 1)'
delete from public.download_jobs where user_id='11111111-1111-1111-1111-111111111111';
reset role;
\echo '=== T11 admin sees all (expect jobs=1 remaining bob, profiles=3)'
set role authenticated; select set_config('request.jwt.claim.sub','33333333-3333-3333-3333-333333333333',false) \gset
select (select count(*) from public.download_jobs) jobs,(select count(*) from public.profiles) profiles, public.is_admin() is_admin;
\echo '=== T12 admin dashboard stats works'
select * from public.admin_dashboard_stats();
reset role;
\echo '=== T13 anon: reads jobs/profiles (expect permission/0), public settings ok'
set role anon; select set_config('request.jwt.claim.sub','',false), set_config('request.jwt.claim.role','anon',false) \gset
select count(*) from public.download_jobs;
select count(*) from public.profiles;
select count(*) from public.admin_roles;
reset role;
