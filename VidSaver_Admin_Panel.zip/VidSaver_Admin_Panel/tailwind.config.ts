import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: { 950: "#050b1a", 900: "#081126", 800: "#0d1b3a", 700: "#14264d", 600: "#1d3563" },
        cyan: { 300: "#67e8f9", 400: "#22d3ee", 500: "#06b6d4" },
      },
      fontFamily: {
        sans: ["ui-sans-serif", "system-ui", "-apple-system", "Segoe UI", "Roboto", "Helvetica Neue", "Arial", "sans-serif"],
      },
      boxShadow: { glow: "0 0 0 1px rgba(34,211,238,.25), 0 8px 40px -8px rgba(34,211,238,.35)" },
    },
  },
  plugins: [],
};
export default config;
