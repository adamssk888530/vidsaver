# VidSaver — User App

**One Link. Easy Saving.** A Next.js (App Router) + TypeScript + Tailwind PWA backed by Supabase.
This project shares **one Supabase project** with the separate *VidSaver Admin Panel*.

```
                    ┌─────────────────────────────┐
  Users (phones,    │  VidSaver User App (Vercel) │──┐
  tablets, desktop) │  Next.js PWA + API routes   │  │  anon key + user JWT (RLS)
        ───────────▶│                             │  │  service key (server only, limited use)
                    └─────────────────────────────┘  ▼
                                                  ┌──────────────────────────┐
                                                  │  ONE Supabase project    │
                                                  │  Auth · Postgres · RLS   │
                                                  └──────────────────────────┘
                    ┌─────────────────────────────┐  ▲
  Administrators ──▶│ VidSaver Admin Panel (Vercel)│──┘  user JWT + is_admin() RLS / RPC
                    │ Next.js, server-verified RBAC│     service key (server only, auth admin ops)
                    └─────────────────────────────┘
```

## What is implemented

- Landing page, link analyzer (Paste Link / Analyze Link), format & quality selection, real download progress, history
- Provider-adapter architecture with a **demo provider** (bundled original test clip). No third-party site is supported out of the box
- Sign up / sign in / sign out / password reset, protected account, settings, history with pagination & deletion, account deletion
- PWA: manifest, service worker (static assets only), offline page, install button + Add-to-Home-Screen guidance, update prompt
- Security: server-side URL validation + SSRF guards, signed short-lived download tokens, rate limiting, security headers + CSP, env validation, RLS
- Consent-gated, privacy-conscious analytics (no IP / user agent / full URL stored)

## Requirements

- Node.js 20.9+ (22 recommended) and npm
- A Supabase project (free tier is fine)
- Optional: a Vercel account for deployment

## Installation

```bash
unzip VidSaver_User_App.zip && cd VidSaver_User_App
npm install
cp .env.example .env.local                   # then fill in the values
```

## Supabase setup (shared with the Admin Panel)

1. Create a project at <https://supabase.com>. **Use the same project for the Admin Panel.**
2. **Apply the schema** — either:
   - Supabase Dashboard → SQL Editor → paste `supabase/migrations/0001_init.sql` → Run, **or**
   - `npx supabase link --project-ref <ref>` then `npx supabase db push`
   (Run it **once**. The admin panel ships the identical file; do not run it twice with changes.)
3. Dashboard → Project Settings → API: copy the **Project URL**, **anon public** key and **service_role** key.
4. Dashboard → Authentication → URL Configuration: set **Site URL** to your site (e.g. `http://localhost:3000`) and add `http://localhost:3000/auth/callback` and `https://YOUR-DOMAIN/auth/callback` to **Redirect URLs**.
5. Authentication → Providers → Email: keep email confirmation on for production.

## Environment variables

| Variable | Scope | Purpose |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | public | Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | public | Anon key (safe; protected by RLS) |
| `NEXT_PUBLIC_SITE_URL` | public | Your site URL |
| `SUPABASE_SERVICE_ROLE_KEY` | **server only** | Guest job records, consent-gated analytics, account deletion |
| `DOWNLOAD_TOKEN_SECRET` | **server only** | ≥32 random chars; signs download tokens (`openssl rand -base64 48`) |
| `ENABLE_DEMO_PROVIDER` | server | `true` to enable the demo provider |
| `NEXT_PUBLIC_CONTACT_EMAIL` | public | Shown on the Contact page |

Never prefix secrets with `NEXT_PUBLIC_`. Never commit `.env*` files (the `.gitignore` already excludes them).

## Local development

```bash
npm run dev          # http://localhost:3000
npm run typecheck
npm run lint
```

Try the demo: paste `https://demo.vidsaver.example/sample-1` → **Analyze Link** → **Download**.
Anything else is rejected as unsupported (by design).

## PWA testing

The service worker registers **only in production builds** and needs **HTTPS** (localhost is exempt).

```bash
npm run build && npm start
```

Then open Chrome DevTools → Application → Manifest / Service Workers, and run Lighthouse → PWA.
Installation behaviour differs by device: Chromium shows an install prompt; iOS Safari has none (use Share → Add to Home Screen).
The app never claims it is installed unless the browser reports it (`appinstalled` event or standalone display mode).

## Production build & Vercel deployment

```bash
npm run build
```

1. Push the project to a Git repository and import it in Vercel (framework: Next.js).
2. Add all environment variables above in Vercel → Settings → Environment Variables.
3. Deploy, then add the production domain to Supabase **Redirect URLs** and **Site URL**.
4. Schedule history retention (optional): in Supabase enable `pg_cron` and run
   `select cron.schedule('vidsaver-purge', '0 3 * * *', $$select public.purge_expired_history()$$);`

## API contracts

| Route | Method | Body / query | Response |
|---|---|---|---|
| `/api/analyze` | POST | `{ url }` | `AnalyzeResponse` or `ApiError` (see `src/lib/types.ts`) |
| `/api/download` | GET | `?token=…&format=…` | Streams the file; sets `Content-Length` when truly known |
| `/api/jobs` | GET / DELETE | `?page=` / `?id=` or `?all=true` | Caller's own history (RLS) |
| `/api/events` | POST | `{ type, path? }` | `204`; stored only with analytics consent |
| `/api/seen` | POST | — | `204`; updates caller's `last_seen_at` |
| `/api/account` | DELETE | — | Deletes the caller's account |

Job status values (shared): `queued · analyzing · ready · downloading · completed · failed · unsupported`.

## Adding a real provider

Implement `ProviderAdapter` (`src/lib/providers/types.ts`), register it in `src/lib/providers/index.ts`, and add a row to
`provider_configs`. Only integrate sources you are **authorized** to use (your own content, licensed APIs, public-domain or
explicitly downloadable media). Any outbound request must call `assertPublicHost()` from `src/lib/urlguard.ts`.

## Limitations of provider integrations

- Only the demo provider ships. **No social-media site is supported**, and none is claimed to be.
- Many platforms forbid downloading in their terms and/or use DRM or authentication. This project does not bypass those.
- Audio-only extraction is disabled unless a provider sets `supportsAudioOnly` and actually implements it.
- Rate limiting is in-memory by default (best-effort on serverless). Swap `src/lib/ratelimit.ts` for Redis/KV in production.
- The CSP allows inline scripts because Next.js needs them without a nonce setup; consider nonce-based CSP for stricter hosting.
- Browser downloads buffer the file in memory to show progress; for very large files use a direct streamed download.

## Security checklist

- [ ] `SUPABASE_SERVICE_ROLE_KEY` and `DOWNLOAD_TOKEN_SECRET` set only as server env vars
- [ ] `0001_init.sql` applied and RLS enabled on every table (it is, in the migration)
- [ ] Email confirmation enabled; redirect URLs restricted to your domains
- [ ] HTTPS enforced on the production domain
- [ ] Shared rate limiter configured for production
- [ ] Privacy Policy / Terms reviewed by a lawyer and contact email set
- [ ] You only enable providers you are authorized to use

## Verification status (honest report)

| Check | Result |
|---|---|
| `0001_init.sql` applied to PostgreSQL 16 with Supabase `auth` stubbed | **Passed** (clean apply, RLS enabled on all 10 tables) |
| RLS isolation / privilege-escalation tests (`supabase/tests/`) — 13 scenarios | **Passed** |
| URL guard (`src/lib/urlguard.ts`): 15 hostile inputs rejected, 2 valid accepted; private-IP classifier | **Passed** |
| `public/sw.js` syntax, `manifest.webmanifest` JSON | **Passed** |
| Secret scan of the ZIP; no `.env`, no `node_modules` | **Passed** |
| `npm install`, `tsc`, `next lint`, `next build` | **Blocked** — the build sandbox could not reach the npm registry. Run them yourself before deploying. |
| End-to-end flows against a live Supabase project, PWA install on a real device | **Not run** (needs your Supabase project / HTTPS host) |

Known limitation: RLS lets a signed-in user update their *own* `download_jobs` rows (needed for status feedback), so a user could
falsify their own job status in the admin statistics. For tamper-proof numbers, move status updates to the server (service role) and drop `jobs_update_own`.
