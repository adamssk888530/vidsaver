import { LogoMark } from "@/components/Logo";

export const metadata = { title: "About" };

export default function AboutPage() {
  return (
    <article className="prose-legal mx-auto max-w-2xl">
      <div className="flex items-center gap-3"><LogoMark size={48} /><h1 className="text-3xl font-bold">About VidSaver</h1></div>
      <p className="mt-4 text-lg text-slate-200">One Link. Easy Saving.</p>
      <p>
        VidSaver is a progressive web app that helps you save media from sources that permit it. Paste a link, see what is
        genuinely available, choose a quality and download — with real progress and clear results.
      </p>
      <h2>What makes it different</h2>
      <ul>
        <li>It only supports explicitly integrated, authorized sources and tells you plainly when a link is not supported.</li>
        <li>It never bypasses DRM, logins, paywalls or privacy settings.</li>
        <li>It installs on Android, iPhone, tablets and desktops, and respects your privacy choices.</li>
      </ul>
    </article>
  );
}
