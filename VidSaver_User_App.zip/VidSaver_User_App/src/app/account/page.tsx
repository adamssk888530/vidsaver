import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Profile } from "@/lib/types";

export const metadata = { title: "Account" };
export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/account");

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle<Profile>();
  const [{ count: total }, { count: ok }, { count: failed }] = await Promise.all([
    supabase.from("download_jobs").select("id", { count: "exact", head: true }),
    supabase.from("download_jobs").select("id", { count: "exact", head: true }).eq("status", "completed"),
    supabase.from("download_jobs").select("id", { count: "exact", head: true }).eq("status", "failed"),
  ]);

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="text-3xl font-bold">Your account</h1>
      {profile?.status === "suspended" && (
        <div className="alert-error" role="alert">This account is suspended. Downloads are disabled. Contact support if you think this is a mistake.</div>
      )}
      <section className="card">
        <dl className="grid gap-4 sm:grid-cols-2">
          <div><dt className="text-xs uppercase tracking-wide text-slate-400">Name</dt><dd className="mt-1">{profile?.display_name || "—"}</dd></div>
          <div><dt className="text-xs uppercase tracking-wide text-slate-400">Email</dt><dd className="mt-1 break-all">{user.email}</dd></div>
          <div><dt className="text-xs uppercase tracking-wide text-slate-400">Member since</dt><dd className="mt-1">{new Date(user.created_at).toLocaleDateString()}</dd></div>
          <div><dt className="text-xs uppercase tracking-wide text-slate-400">Status</dt><dd className="mt-1 capitalize">{profile?.status ?? "active"}</dd></div>
        </dl>
      </section>
      <section className="grid grid-cols-3 gap-3 text-center">
        {[["Requests", total ?? 0], ["Completed", ok ?? 0], ["Failed", failed ?? 0]].map(([l, v]) => (
          <div key={l as string} className="card"><p className="text-2xl font-bold text-cyan-300">{v}</p><p className="text-xs text-slate-400">{l}</p></div>
        ))}
      </section>
      <div className="flex flex-wrap gap-3">
        <Link href="/settings" className="btn-primary">Profile settings</Link>
        <Link href="/history" className="btn-ghost">Download history</Link>
      </div>
    </div>
  );
}
