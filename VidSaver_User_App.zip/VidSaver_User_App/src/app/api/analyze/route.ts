import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { parseUserUrl, UrlRejected } from "@/lib/urlguard";
import { findProvider } from "@/lib/providers";
import { ProviderError } from "@/lib/providers/types";
import { limiter, clientIp } from "@/lib/ratelimit";
import { createJob, hashUrl, safeMessage } from "@/lib/jobs";
import { getOrCreateAnonId } from "@/lib/session";
import { signToken } from "@/lib/token";
import type { AnalyzeResponse, ApiError } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const body = z.object({ url: z.string().max(2048) });

const err = (status: number, code: ApiError["code"], message: string, headers?: HeadersInit) =>
  NextResponse.json<ApiError>({ ok: false, code, message }, { status, headers });

export async function POST(req: Request) {
  const rl = await limiter.check(`analyze:${clientIp(req)}`, 20, 60_000);
  if (!rl.allowed) {
    return err(429, "rate_limited", "Too many requests. Please wait a moment and try again.", {
      "Retry-After": String(rl.retryAfterSec),
    });
  }

  let parsedBody: z.infer<typeof body>;
  try {
    parsedBody = body.parse(await req.json());
  } catch {
    return err(400, "bad_request", "Send a JSON body like { \"url\": \"https://…\" }.");
  }

  let url: URL;
  try {
    url = parseUserUrl(parsedBody.url);
  } catch (e) {
    return err(400, "invalid_url", e instanceof UrlRejected ? e.reason : "That link is not valid.");
  }

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user) {
    const { data: profile } = await supabase.from("profiles").select("status").eq("id", user.id).maybeSingle();
    if (profile?.status === "suspended") {
      return err(403, "unauthorized", "This account is suspended. Please contact support.");
    }
  }
  const anonId = user ? null : await getOrCreateAnonId();

  const provider = findProvider(url);
  if (!provider) {
    await createJob(supabase, user, anonId, {
      provider: "unsupported",
      source_host: url.hostname.slice(0, 253),
      source_hash: hashUrl(url),
      status: "unsupported",
      error_code: "unsupported_provider",
    });
    return err(
      422,
      "unsupported_provider",
      "This website isn't supported. VidSaver only works with explicitly integrated sources that permit downloading — it does not claim to save from every site."
    );
  }

  try {
    const result = await provider.analyze(url);
    const jobId = await createJob(supabase, user, anonId, {
      provider: provider.id,
      source_host: url.hostname.slice(0, 253),
      source_hash: hashUrl(url),
      status: "ready",
    });
    const token = signToken({ j: jobId, p: provider.id, i: result.itemId, u: user?.id ?? null, a: anonId });
    return NextResponse.json<AnalyzeResponse>(
      {
        ok: true,
        provider: { id: provider.id, name: provider.displayName, mode: provider.mode },
        media: {
          title: result.title.slice(0, 200),
          durationSec: result.durationSec,
          thumbnailUrl: result.thumbnailUrl ?? null,
          previewAllowed: result.previewAllowed,
          formats: result.formats,
          audioOnlySupported: provider.supportsAudioOnly,
        },
        token,
        jobId,
      },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch (e) {
    const pe = e instanceof ProviderError ? e : null;
    await createJob(supabase, user, anonId, {
      provider: provider.id,
      source_host: url.hostname.slice(0, 253),
      source_hash: hashUrl(url),
      status: "failed",
      error_code: pe?.code ?? "provider_error",
      error_message: safeMessage(pe?.message ?? "Provider error"),
    });
    if (pe?.code === "private_or_restricted") {
      return err(403, "provider_unavailable", "This item is private or restricted, so it can't be saved.");
    }
    if (pe?.code === "not_found") return err(404, "provider_unavailable", pe.message);
    return err(502, "provider_unavailable", "The source is currently unavailable. Please try again later.");
  }
}
