import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { verifyToken } from "@/lib/token";
import { getProviderById } from "@/lib/providers";
import { ProviderError } from "@/lib/providers/types";
import { limiter, clientIp } from "@/lib/ratelimit";
import { updateJob } from "@/lib/jobs";
import { readAnonId } from "@/lib/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const json = (status: number, message: string, headers?: HeadersInit) =>
  NextResponse.json({ ok: false, message }, { status, headers });

export async function GET(req: Request) {
  const rl = await limiter.check(`download:${clientIp(req)}`, 30, 60_000);
  if (!rl.allowed) return json(429, "Too many requests.", { "Retry-After": String(rl.retryAfterSec) });

  const { searchParams } = new URL(req.url);
  const token = searchParams.get("token") ?? "";
  const formatId = (searchParams.get("format") ?? "").slice(0, 40);
  const claims = verifyToken(token);
  if (!claims || !/^[a-z0-9-]{1,40}$/.test(formatId)) return json(403, "This download link is invalid or has expired.");

  // Bind the token to the same person who analyzed the link.
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (claims.u) {
    if (!user || user.id !== claims.u) return json(401, "Please sign in as the account that analyzed this link.");
  } else if (claims.a) {
    if ((await readAnonId()) !== claims.a) return json(403, "This download link belongs to a different session.");
  }

  const provider = getProviderById(claims.p);
  if (!provider) return json(404, "That provider is no longer available.");

  await updateJob(supabase, user, claims.j, { status: "downloading", format: formatId });

  let opened;
  try {
    opened = await provider.open(claims.i, formatId);
  } catch (e) {
    const msg = e instanceof ProviderError ? e.message : "The source could not be reached.";
    await updateJob(supabase, user, claims.j, {
      status: "failed",
      error_code: e instanceof ProviderError ? e.code : "provider_error",
      error_message: msg.slice(0, 280),
    });
    return json(e instanceof ProviderError && e.code === "format_unavailable" ? 400 : 502, msg);
  }

  // Count real bytes as they stream; record the true outcome when the stream ends.
  let bytes = 0;
  let settled = false;
  const finish = async (ok: boolean, code?: string) => {
    if (settled) return;
    settled = true;
    await updateJob(
      supabase,
      user,
      claims.j,
      ok
        ? { status: "completed", bytes, completed_at: new Date().toISOString() }
        : { status: "failed", bytes, error_code: code ?? "stream_error", error_message: "Transfer did not complete" }
    );
  };

  const reader = opened.stream.getReader();
  const body = new ReadableStream<Uint8Array>({
    async pull(controller) {
      try {
        const { done, value } = await reader.read();
        if (done) {
          controller.close();
          await finish(true);
          return;
        }
        bytes += value.byteLength;
        controller.enqueue(value);
      } catch {
        controller.error(new Error("stream failed"));
        await finish(false, "stream_error");
      }
    },
    async cancel() {
      await reader.cancel().catch(() => {});
      await finish(false, "client_aborted");
    },
  });

  const safeName = opened.filename.replace(/[^\w.\- ]/g, "_").slice(0, 100);
  const headers: Record<string, string> = {
    "Content-Type": opened.contentType,
    "Content-Disposition": `attachment; filename="${safeName}"`,
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  };
  if (opened.contentLength != null) headers["Content-Length"] = String(opened.contentLength);
  return new Response(body, { headers });
}
