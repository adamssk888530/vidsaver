import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";
import { getOrCreateAnonId } from "@/lib/session";
import { limiter, clientIp } from "@/lib/ratelimit";
import { ANALYTICS_EVENTS } from "@/lib/types";

export const dynamic = "force-dynamic";

const schema = z.object({
  type: z.enum(ANALYTICS_EVENTS),
  path: z.string().max(200).optional(),
});

/**
 * Privacy-conscious analytics. Events are stored ONLY if the visitor granted analytics consent
 * (cookie "vs_consent=analytics", set by the consent banner). No IP address, user agent, query
 * string or full URL is stored — just event type, path, a random first-party session id and a timestamp.
 * Install counts are SIGNALS, not exact installs: browsers do not reliably report installation.
 */
export async function POST(req: Request) {
  if ((await cookies()).get("vs_consent")?.value !== "analytics") {
    return new NextResponse(null, { status: 204 });
  }
  const rl = await limiter.check(`events:${clientIp(req)}`, 60, 60_000);
  if (!rl.allowed) return new NextResponse(null, { status: 429 });

  let parsed: z.infer<typeof schema>;
  try {
    parsed = schema.parse(await req.json());
  } catch {
    return NextResponse.json({ ok: false }, { status: 400 });
  }
  const admin = createAdminClient();
  if (!admin) return new NextResponse(null, { status: 204 });

  const path = parsed.path?.split(/[?#]/)[0];
  await admin.from("analytics_events").insert({
    event_type: parsed.type,
    path: path && path.startsWith("/") ? path : null,
    anon_session_id: await getOrCreateAnonId(),
  });
  return new NextResponse(null, { status: 204 });
}
