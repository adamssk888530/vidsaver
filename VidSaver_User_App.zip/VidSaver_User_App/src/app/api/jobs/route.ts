import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 10;

/** GET /api/jobs?page=1  → the caller's own history (RLS-enforced), paginated. */
export async function GET(req: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ ok: false, message: "Sign in to see your history." }, { status: 401 });

  const page = Math.max(1, Math.min(10_000, Number(new URL(req.url).searchParams.get("page")) || 1));
  const from = (page - 1) * PAGE_SIZE;
  const { data, count, error } = await supabase
    .from("download_jobs")
    .select("id,provider,source_host,format,quality,status,error_message,bytes,created_at,completed_at", { count: "exact" })
    .order("created_at", { ascending: false })
    .range(from, from + PAGE_SIZE - 1);
  if (error) return NextResponse.json({ ok: false, message: "Could not load history." }, { status: 500 });
  return NextResponse.json({ ok: true, items: data, total: count ?? 0, page, pageSize: PAGE_SIZE });
}

/** DELETE /api/jobs?id=<uuid>  or  /api/jobs?all=true  → delete own history rows only (RLS). */
export async function DELETE(req: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ ok: false, message: "Unauthorized" }, { status: 401 });

  const sp = new URL(req.url).searchParams;
  const id = sp.get("id");
  let q = supabase.from("download_jobs").delete().eq("user_id", user.id);
  if (id) {
    if (!/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({ ok: false, message: "Bad id" }, { status: 400 });
    q = q.eq("id", id);
  } else if (sp.get("all") !== "true") {
    return NextResponse.json({ ok: false, message: "Specify id or all=true" }, { status: 400 });
  }
  const { error } = await q;
  if (error) return NextResponse.json({ ok: false, message: "Could not delete." }, { status: 500 });
  return NextResponse.json({ ok: true });
}
