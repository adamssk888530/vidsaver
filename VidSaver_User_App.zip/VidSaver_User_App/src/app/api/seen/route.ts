import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

/** Updates the caller's own last_seen_at (used for the admin "active users" metric). */
export async function POST() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return new NextResponse(null, { status: 204 });
  await supabase.from("profiles").update({ last_seen_at: new Date().toISOString() }).eq("id", user.id);
  return new NextResponse(null, { status: 204 });
}
