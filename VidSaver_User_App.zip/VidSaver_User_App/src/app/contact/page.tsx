export const metadata = { title: "Contact" };

export default function ContactPage() {
  const email = process.env.NEXT_PUBLIC_CONTACT_EMAIL;
  return (
    <div className="mx-auto max-w-xl space-y-4">
      <h1 className="text-3xl font-bold">Contact</h1>
      <div className="card">
        {email ? (
          <>
            <p className="text-slate-200">Questions, privacy requests or takedown notices? Email us:</p>
            <a className="btn-primary mt-4" href={`mailto:${email}`}>{email}</a>
          </>
        ) : (
          <div className="alert-info">
            No contact address is configured yet. Set <code>NEXT_PUBLIC_CONTACT_EMAIL</code> in your environment variables
            to show one here.
          </div>
        )}
      </div>
    </div>
  );
}
