import { HistoryList } from "@/components/HistoryList";

export const metadata = { title: "History" };

export default function HistoryPage() {
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <h1 className="text-3xl font-bold">Download history</h1>
      <p className="text-sm text-slate-300">
        Only you can see this list. We store the site name, format, status and time — never the full link. Entries are
        removed automatically after your retention period (set in Settings).
      </p>
      <div className="card"><HistoryList /></div>
    </div>
  );
}
