import type { Metadata, Viewport } from "next";
import Link from "next/link";
import "./globals.css";
import { Header } from "@/components/Header";
import { BottomNav } from "@/components/BottomNav";
import { SwRegister } from "@/components/SwRegister";
import { ConsentBanner } from "@/components/ConsentBanner";
import { SeenPing } from "@/components/SeenPing";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = {
  title: { default: "VidSaver — One Link. Easy Saving.", template: "%s · VidSaver" },
  description: "Paste a link from a supported source, pick a quality, and save. Installable on any device.",
  applicationName: "VidSaver",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/icons/icon-192.png", apple: "/icons/apple-touch-icon.png" },
  appleWebApp: { capable: true, title: "VidSaver", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  themeColor: "#081126",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <html lang="en">
      <body>
        <a href="#main" className="skip-link">Skip to content</a>
        <Header />
        <main id="main" className="mx-auto max-w-5xl px-4 pb-32 pt-6 md:pb-16">
          {children}
        </main>
        <footer className="mx-auto hidden max-w-5xl border-t border-white/10 px-4 py-6 text-sm text-slate-400 md:block">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span>© {new Date().getFullYear()} VidSaver · One Link. Easy Saving.</span>
            <nav aria-label="Legal" className="flex gap-4">
              <Link href="/privacy" className="hover:text-white">Privacy</Link>
              <Link href="/terms" className="hover:text-white">Terms</Link>
              <Link href="/about" className="hover:text-white">About</Link>
              <Link href="/contact" className="hover:text-white">Contact</Link>
            </nav>
          </div>
        </footer>
        <BottomNav />
        <SwRegister />
        <ConsentBanner />
        <SeenPing signedIn={!!user} />
      </body>
    </html>
  );
}
