import Link from "next/link";

export default function NotFound() {
  return (
    <div className="py-20 text-center">
      <h1 className="text-4xl font-black">404</h1>
      <p className="mt-2 text-slate-300">We couldn’t find that page.</p>
      <Link href="/" className="btn-primary mt-6">Back home</Link>
    </div>
  );
}
