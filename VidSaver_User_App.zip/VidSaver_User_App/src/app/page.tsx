import { ShieldCheck, Zap, Smartphone } from "lucide-react";
import { HomeClient } from "@/components/HomeClient";

export default function HomePage() {
  return (
    <div>
      <section className="py-8 text-center sm:py-14">
        <p className="mx-auto mb-4 w-fit rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1 text-xs font-medium text-cyan-200">
          Installable · Works on Android, iPhone, tablet &amp; desktop
        </p>
        <h1 className="text-4xl font-black tracking-tight text-white sm:text-6xl">
          One Link. <span className="text-cyan-400">Easy Saving.</span>
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-base text-slate-300 sm:text-lg">
          Paste a link, choose a quality, and save — from sources that allow it.
        </p>
      </section>

      <HomeClient />

      <section aria-label="Why VidSaver" className="mt-10 grid gap-4 sm:grid-cols-3">
        {[
          { Icon: ShieldCheck, t: "Honest by design", d: "Only explicitly integrated, authorized sources. No DRM or privacy bypassing." },
          { Icon: Zap, t: "Real progress", d: "Sizes, progress and results reflect what actually happened — never faked." },
          { Icon: Smartphone, t: "Install it", d: "Add VidSaver to your home screen for a full-screen, app-like experience." },
        ].map(({ Icon, t, d }) => (
          <div key={t} className="card">
            <Icon className="text-cyan-400" size={22} aria-hidden="true" />
            <h3 className="mt-3 font-semibold text-white">{t}</h3>
            <p className="mt-1 text-sm text-slate-300">{d}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
