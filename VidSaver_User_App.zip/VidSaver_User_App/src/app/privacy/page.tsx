export const metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <article className="prose-legal mx-auto max-w-2xl">
      <h1 className="text-3xl font-bold">Privacy Policy</h1>
      <p className="mt-2 text-sm text-slate-400">Template provided with the VidSaver source. Have it reviewed by a qualified lawyer and adapt it to your jurisdiction (for example NDPR/NDPA in Nigeria, GDPR in the EU) before launch.</p>

      <h2>What we collect</h2>
      <ul>
        <li><strong>Account data:</strong> email address, optional display name, and preferences you set.</li>
        <li><strong>Download history:</strong> the website name (host only), format, quality, status, size and time of each request. We do not store the full link you paste.</li>
        <li><strong>Guest sessions:</strong> a random, first-party identifier in an essential cookie so a guest can complete a download they started.</li>
        <li><strong>Analytics (only with your consent):</strong> page path, install-button clicks and install signals, with a random session id. No IP address, user agent or full URL is stored.</li>
      </ul>

      <h2>How we use it</h2>
      <p>To run the service, prevent abuse, show your history, and — if you opt in — understand which pages and features are used.</p>

      <h2>Your choices</h2>
      <ul>
        <li>Choose “Essential only” on the consent banner to disable analytics.</li>
        <li>Set how long history is kept, or delete it at any time from the History page.</li>
        <li>Delete your account and associated data from Settings.</li>
      </ul>

      <h2>Sharing &amp; storage</h2>
      <p>Data is stored with our infrastructure provider (Supabase) and protected by access controls. We do not sell personal data. Advertising, if ever enabled, will be disclosed here and will respect your consent choices.</p>

      <h2>Contact</h2>
      <p>Use the Contact page for privacy requests.</p>
    </article>
  );
}
