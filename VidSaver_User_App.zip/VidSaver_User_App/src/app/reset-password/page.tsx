import { Suspense } from "react";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/AuthForm";
import { createClient } from "@/lib/supabase/server";

export const metadata = { title: "New password" };

export default async function Page() {
  // The reset link signs the user in via /auth/callback; without a session there is nothing to update.
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/forgot-password?error=1");
  return (
    <Suspense>
      <AuthForm mode="reset" />
    </Suspense>
  );
}
