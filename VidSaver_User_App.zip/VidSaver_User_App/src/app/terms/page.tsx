export const metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <article className="prose-legal mx-auto max-w-2xl">
      <h1 className="text-3xl font-bold">Terms of Service</h1>
      <p className="mt-2 text-sm text-slate-400">Template provided with the VidSaver source. Have it reviewed by a qualified lawyer before launch.</p>

      <h2>Acceptable use</h2>
      <ul>
        <li>Only save content you own, that is in the public domain, that is licensed for download, or that the source explicitly permits you to save.</li>
        <li>You are responsible for complying with copyright law and the terms of the website you save from.</li>
        <li>Do not attempt to bypass DRM, paywalls, logins, privacy settings or technical restrictions. VidSaver does not support this.</li>
        <li>Do not abuse, overload or probe the service, or attempt to access other people’s data.</li>
      </ul>

      <h2>Supported sources</h2>
      <p>VidSaver works only with sources that have an integrated, authorized provider. We do not guarantee that any particular website is supported, and availability can change.</p>

      <h2>Accounts</h2>
      <p>Keep your credentials secure. We may suspend accounts that breach these terms.</p>

      <h2>No warranty</h2>
      <p>The service is provided “as is”. To the extent permitted by law, we are not liable for loss arising from its use.</p>

      <h2>Changes</h2>
      <p>We may update these terms; continued use means you accept the updated version.</p>
    </article>
  );
}
