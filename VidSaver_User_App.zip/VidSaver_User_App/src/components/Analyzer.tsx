"use client";
import { useRef, useState } from "react";
import { ClipboardPaste, Search, Download, Loader2, CheckCircle2, AlertTriangle, Music } from "lucide-react";
import type { AnalyzeResponse, ApiError } from "@/lib/types";

type Phase = "idle" | "analyzing" | "ready" | "downloading" | "done" | "error";

const fmtBytes = (n?: number | null) =>
  n == null ? "unknown size" : n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1e3))} KB`;

export function Analyzer({ onFinished }: { onFinished?: () => void }) {
  const [url, setUrl] = useState("");
  const [phase, setPhase] = useState<Phase>("idle");
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalyzeResponse | null>(null);
  const [formatId, setFormatId] = useState<string>("");
  const [progress, setProgress] = useState<{ received: number; total: number | null }>({ received: 0, total: null });
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const paste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text.trim());
      setError(null);
    } catch {
      setError("Your browser blocked clipboard access. Paste the link into the box manually.");
      setPhase("error");
    }
  };

  const analyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    setPhase("analyzing");
    setError(null);
    setResult(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      const data = (await res.json()) as AnalyzeResponse | ApiError;
      if (!data.ok) {
        setError(data.message);
        setPhase("error");
        return;
      }
      setResult(data);
      setFormatId(data.media.formats[0]?.id ?? "");
      setPhase("ready");
    } catch {
      setError("Network error. Check your connection and try again.");
      setPhase("error");
    }
  };

  const download = async () => {
    if (!result || !formatId) return;
    setPhase("downloading");
    setError(null);
    setProgress({ received: 0, total: null });
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    try {
      const res = await fetch(
        `/api/download?token=${encodeURIComponent(result.token)}&format=${encodeURIComponent(formatId)}`,
        { signal: ctrl.signal }
      );
      if (!res.ok || !res.body) {
        const msg = await res.json().then((j) => j.message as string).catch(() => "Download failed.");
        throw new Error(msg);
      }
      const total = Number(res.headers.get("Content-Length")) || null;
      setProgress({ received: 0, total });
      const reader = res.body.getReader();
      const chunks: Uint8Array[] = [];
      let received = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
        received += value.byteLength;
        setProgress({ received, total });
      }
      const blob = new Blob(chunks as BlobPart[], { type: res.headers.get("Content-Type") ?? "application/octet-stream" });
      const objectUrl = URL.createObjectURL(blob);
      const cd = res.headers.get("Content-Disposition") ?? "";
      const name = /filename="([^"]+)"/.exec(cd)?.[1] ?? "vidsaver-download";
      const a = document.createElement("a");
      a.href = objectUrl;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      if (result.media.previewAllowed && blob.type.startsWith("video/")) setPreviewUrl(objectUrl);
      else setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
      setPhase("done");
      onFinished?.();
    } catch (err) {
      if ((err as Error).name === "AbortError") {
        setPhase("ready");
        return;
      }
      setError((err as Error).message || "Download failed.");
      setPhase("error");
      onFinished?.();
    }
  };

  const pct = progress.total ? Math.min(100, Math.round((progress.received / progress.total) * 100)) : null;

  return (
    <section aria-labelledby="analyzer-title" className="card shadow-glow">
      <h2 id="analyzer-title" className="sr-only">Link analyzer</h2>
      <form onSubmit={analyze} noValidate>
        <label htmlFor="url" className="label">Paste a link from a supported source</label>
        <div className="flex flex-col gap-3 sm:flex-row">
          <input
            id="url"
            name="url"
            type="url"
            inputMode="url"
            autoComplete="off"
            spellCheck={false}
            placeholder="https://…"
            className="input flex-1"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            aria-describedby="url-help"
          />
          <div className="flex gap-2">
            <button type="button" className="btn-ghost flex-1 sm:flex-none" onClick={paste}>
              <ClipboardPaste size={16} aria-hidden="true" /> Paste Link
            </button>
            <button type="submit" className="btn-primary flex-1 sm:flex-none" disabled={phase === "analyzing" || phase === "downloading" || !url.trim()}>
              {phase === "analyzing" ? <Loader2 size={16} className="animate-spin" aria-hidden="true" /> : <Search size={16} aria-hidden="true" />}
              Analyze Link
            </button>
          </div>
        </div>
        <p id="url-help" className="mt-2 text-xs text-slate-400">
          Demo: try <code className="rounded bg-white/10 px-1.5 py-0.5">https://demo.vidsaver.example/sample-1</code>. Only sources with an
          integrated provider are supported.
        </p>
      </form>

      <div aria-live="polite" className="mt-4 space-y-4">
        {phase === "analyzing" && (
          <div className="flex items-center gap-2 text-sm text-slate-200"><Loader2 className="animate-spin" size={16} /> Checking the link…</div>
        )}

        {phase === "error" && error && (
          <div className="alert-error flex gap-2" role="alert">
            <AlertTriangle size={18} className="mt-0.5 shrink-0" aria-hidden="true" /> <span>{error}</span>
          </div>
        )}

        {result && (phase === "ready" || phase === "downloading" || phase === "done" || (phase === "error" && result)) && (
          <div className="rounded-xl border border-white/10 bg-navy-900/60 p-4">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <h3 className="font-semibold text-white">{result.media.title}</h3>
                <p className="text-xs text-slate-400">
                  Source: {result.provider.name}
                  {result.media.durationSec ? ` · ${result.media.durationSec}s` : ""}
                </p>
              </div>
              {result.provider.mode === "demo" && (
                <span className="rounded-full border border-amber-300/40 bg-amber-400/10 px-2.5 py-1 text-xs text-amber-100">Demo provider · sample media</span>
              )}
            </div>

            <fieldset className="mt-4" disabled={phase === "downloading"}>
              <legend className="label">Format &amp; quality</legend>
              <div className="grid gap-2 sm:grid-cols-2">
                {result.media.formats.map((f) => (
                  <label key={f.id} className={`flex cursor-pointer items-center justify-between gap-3 rounded-xl border px-3 py-2.5 text-sm ${formatId === f.id ? "border-cyan-400 bg-cyan-400/10" : "border-white/15 hover:bg-white/5"}`}>
                    <span className="flex items-center gap-2">
                      <input type="radio" name="format" value={f.id} checked={formatId === f.id} onChange={() => setFormatId(f.id)} className="accent-cyan-400" />
                      {f.label}
                    </span>
                    <span className="text-xs text-slate-400">{fmtBytes(f.approxBytes)}</span>
                  </label>
                ))}
                <label className="flex cursor-not-allowed items-center justify-between gap-3 rounded-xl border border-white/10 px-3 py-2.5 text-sm opacity-60" title="Audio-only is not available for this source">
                  <span className="flex items-center gap-2">
                    <input type="radio" disabled aria-disabled="true" />
                    <Music size={14} aria-hidden="true" /> Audio only
                  </span>
                  <span className="text-xs text-slate-400">{result.media.audioOnlySupported ? "available" : "not supported here"}</span>
                </label>
              </div>
            </fieldset>

            {phase === "downloading" ? (
              <div className="mt-4">
                <div className="mb-1 flex justify-between text-xs text-slate-300">
                  <span>Downloading…</span>
                  <span>{pct != null ? `${pct}%` : fmtBytes(progress.received)}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-white/10" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={pct ?? undefined} aria-label="Download progress">
                  <div className={`h-full bg-cyan-400 ${pct == null ? "w-1/3 animate-pulse" : ""}`} style={pct != null ? { width: `${pct}%` } : undefined} />
                </div>
                <button className="btn-ghost mt-3" onClick={() => abortRef.current?.abort()}>Cancel</button>
              </div>
            ) : (
              <button className="btn-primary mt-4 w-full sm:w-auto" onClick={download} disabled={!formatId}>
                <Download size={16} aria-hidden="true" /> Download
              </button>
            )}

            {phase === "done" && (
              <div className="alert-ok mt-4 flex gap-2" role="status">
                <CheckCircle2 size={18} className="mt-0.5 shrink-0" aria-hidden="true" />
                <span>Saved {fmtBytes(progress.received)} to your device.</span>
              </div>
            )}
            {previewUrl && (
              <div className="mt-4">
                <p className="label">Preview of your saved file</p>
                <video src={previewUrl} controls className="w-full rounded-xl bg-black" />
              </div>
            )}
          </div>
        )}

        {phase === "idle" && (
          <p className="text-sm text-slate-400">Paste a link, then press Analyze Link to see what can be saved.</p>
        )}
      </div>
    </section>
  );
}
