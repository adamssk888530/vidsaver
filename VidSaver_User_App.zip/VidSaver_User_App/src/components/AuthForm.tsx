"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Loader2 } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { authMessage } from "@/lib/authErrors";

type Mode = "login" | "signup" | "forgot" | "reset";

const copy: Record<Mode, { title: string; cta: string }> = {
  login: { title: "Welcome back", cta: "Sign in" },
  signup: { title: "Create your account", cta: "Create account" },
  forgot: { title: "Reset your password", cta: "Send reset link" },
  reset: { title: "Choose a new password", cta: "Update password" },
};

function safeNext(v: string | null) {
  return v && v.startsWith("/") && !v.startsWith("//") ? v : "/";
}

export function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(params.get("error") ? "That link is invalid or has expired. Request a new one." : null);
  const [info, setInfo] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setInfo(null);
    const supabase = createClient();
    const origin = window.location.origin;
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) return setError(authMessage(error));
        router.push(safeNext(params.get("next")));
        router.refresh();
      } else if (mode === "signup") {
        if (password.length < 8) return setError("Choose a password with at least 8 characters.");
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { display_name: name.trim().slice(0, 80) }, emailRedirectTo: `${origin}/auth/callback` },
        });
        if (error) return setError(authMessage(error));
        if (data.session) {
          router.push("/");
          router.refresh();
        } else {
          setInfo("Almost there! We sent a confirmation link to your email. Open it to activate your account.");
        }
      } else if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${origin}/auth/callback?next=/reset-password`,
        });
        if (error) return setError(authMessage(error));
        // Same message whether or not the email exists, to avoid account enumeration.
        setInfo("If an account exists for that email, a reset link is on its way.");
      } else {
        if (password.length < 8) return setError("Choose a password with at least 8 characters.");
        const { error } = await supabase.auth.updateUser({ password });
        if (error) return setError(authMessage(error));
        setInfo("Password updated. Redirecting…");
        setTimeout(() => router.push("/account"), 800);
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-md">
      <div className="card">
        <h1 className="text-2xl font-bold">{copy[mode].title}</h1>
        <form onSubmit={submit} className="mt-5 space-y-4">
          {mode === "signup" && (
            <div>
              <label htmlFor="name" className="label">Display name (optional)</label>
              <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} autoComplete="nickname" />
            </div>
          )}
          {mode !== "reset" && (
            <div>
              <label htmlFor="email" className="label">Email</label>
              <input id="email" type="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
            </div>
          )}
          {mode !== "forgot" && (
            <div>
              <label htmlFor="password" className="label">{mode === "reset" ? "New password" : "Password"}</label>
              <input id="password" type="password" required minLength={mode === "login" ? undefined : 8} className="input" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "login" ? "current-password" : "new-password"} />
            </div>
          )}
          {error && <div className="alert-error" role="alert">{error}</div>}
          {info && <div className="alert-ok" role="status">{info}</div>}
          <button className="btn-primary w-full" disabled={busy}>
            {busy && <Loader2 size={16} className="animate-spin" aria-hidden="true" />} {copy[mode].cta}
          </button>
        </form>
        <div className="mt-5 flex flex-wrap justify-between gap-2 text-sm text-slate-300">
          {mode === "login" && (<><Link href="/signup" className="hover:underline">Create account</Link><Link href="/forgot-password" className="hover:underline">Forgot password?</Link></>)}
          {mode === "signup" && <Link href="/login" className="hover:underline">Already have an account? Sign in</Link>}
          {mode === "forgot" && <Link href="/login" className="hover:underline">Back to sign in</Link>}
        </div>
      </div>
      {mode === "login" && (
        <p className="mt-4 text-center text-sm text-slate-400">
          Or <Link href="/" className="text-cyan-300 hover:underline">continue as a guest</Link> — guest history is not saved to an account.
        </p>
      )}
    </div>
  );
}
