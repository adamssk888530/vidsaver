"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { track } from "@/lib/analytics";

function setConsent(value: "analytics" | "essential") {
  document.cookie = `vs_consent=${value}; Max-Age=${60 * 60 * 24 * 365}; Path=/; SameSite=Lax${
    location.protocol === "https:" ? "; Secure" : ""
  }`;
}

export function ConsentBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const has = document.cookie.split("; ").some((c) => c.startsWith("vs_consent="));
    if (!has) setVisible(true);
    else track("page_view");
  }, []);

  if (!visible) return null;
  return (
    <div role="region" aria-label="Privacy choices" className="fixed inset-x-3 bottom-20 z-50 mx-auto max-w-xl rounded-2xl border border-white/15 bg-navy-800 p-4 shadow-glow md:bottom-4">
      <p className="text-sm text-slate-200">
        We use essential storage to keep you signed in. With your permission we also count anonymous page visits
        and install-button clicks to improve VidSaver. No ads, no selling data.{" "}
        <Link href="/privacy" className="underline">Privacy Policy</Link>
      </p>
      <div className="mt-3 flex gap-2">
        <button className="btn-primary" onClick={() => { setConsent("analytics"); setVisible(false); track("page_view"); }}>
          Allow analytics
        </button>
        <button className="btn-ghost" onClick={() => { setConsent("essential"); setVisible(false); }}>
          Essential only
        </button>
      </div>
    </div>
  );
}
