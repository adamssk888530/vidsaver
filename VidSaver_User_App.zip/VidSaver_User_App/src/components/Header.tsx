import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { Logo } from "./Logo";
import { InstallButton } from "./InstallButton";
import { SignOutButton } from "./SignOutButton";

export async function Header() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-navy-950/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4">
        <Link href="/" aria-label="VidSaver home">
          <Logo />
        </Link>
        <nav aria-label="Main" className="hidden items-center gap-1 md:flex">
          <Link className="rounded-lg px-3 py-2 text-sm text-slate-200 hover:bg-white/10" href="/">Home</Link>
          <Link className="rounded-lg px-3 py-2 text-sm text-slate-200 hover:bg-white/10" href="/history">History</Link>
          <Link className="rounded-lg px-3 py-2 text-sm text-slate-200 hover:bg-white/10" href="/settings">Settings</Link>
          <Link className="rounded-lg px-3 py-2 text-sm text-slate-200 hover:bg-white/10" href="/about">About</Link>
          <Link className="rounded-lg px-3 py-2 text-sm text-slate-200 hover:bg-white/10" href="/contact">Contact</Link>
        </nav>
        <div className="flex items-center gap-2">
          <InstallButton />
          {user ? (
            <>
              <Link href="/account" className="btn-ghost hidden sm:inline-flex">Account</Link>
              <SignOutButton />
            </>
          ) : (
            <Link href="/login" className="btn-primary">Sign in</Link>
          )}
        </div>
      </div>
    </header>
  );
}
