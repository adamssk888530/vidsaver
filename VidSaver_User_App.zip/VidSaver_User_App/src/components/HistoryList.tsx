"use client";
import { useCallback, useEffect, useState } from "react";
import { Trash2, Loader2 } from "lucide-react";

interface Item {
  id: string;
  provider: string;
  source_host: string | null;
  format: string | null;
  status: string;
  error_message: string | null;
  bytes: number | null;
  created_at: string;
}

const badge: Record<string, string> = {
  completed: "border-emerald-400/40 text-emerald-200 bg-emerald-500/10",
  failed: "border-red-400/40 text-red-200 bg-red-500/10",
  unsupported: "border-amber-300/40 text-amber-100 bg-amber-400/10",
};

export function HistoryList({ compact = false, refreshKey = 0 }: { compact?: boolean; refreshKey?: number }) {
  const [items, setItems] = useState<Item[] | null>(null);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [error, setError] = useState<string | null>(null);
  const [signedOut, setSignedOut] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    const res = await fetch(`/api/jobs?page=${page}`, { cache: "no-store" });
    if (res.status === 401) return setSignedOut(true);
    const j = await res.json();
    if (!j.ok) return setError(j.message);
    setItems(compact ? j.items.slice(0, 5) : j.items);
    setTotal(j.total);
    setPageSize(j.pageSize);
  }, [page, compact]);

  useEffect(() => {
    load();
  }, [load, refreshKey]);

  const remove = async (id?: string) => {
    if (!id && !confirm("Delete your entire download history? This cannot be undone.")) return;
    await fetch(`/api/jobs?${id ? `id=${id}` : "all=true"}`, { method: "DELETE" });
    setPage(1);
    load();
  };

  if (signedOut) return <p className="text-sm text-slate-400">Sign in to keep a history of your downloads.</p>;
  if (error) return <div className="alert-error">{error}</div>;
  if (!items) return <div className="flex items-center gap-2 text-sm text-slate-300"><Loader2 className="animate-spin" size={16} /> Loading…</div>;
  if (!items.length) return <p className="text-sm text-slate-400">No downloads yet. Analyze a link to get started.</p>;

  const pages = Math.max(1, Math.ceil(total / pageSize));
  return (
    <div>
      <ul className="divide-y divide-white/10">
        {items.map((it) => (
          <li key={it.id} className="flex items-center justify-between gap-3 py-3">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium text-white">
                {it.source_host ?? it.provider} {it.format ? <span className="text-slate-400">· {it.format}</span> : null}
              </p>
              <p className="text-xs text-slate-400">
                {new Date(it.created_at).toLocaleString()}
                {it.error_message ? ` · ${it.error_message}` : ""}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className={`rounded-full border px-2.5 py-0.5 text-xs ${badge[it.status] ?? "border-white/20 text-slate-200"}`}>{it.status}</span>
              {!compact && (
                <button className="rounded-lg p-2 text-slate-300 hover:bg-white/10" onClick={() => remove(it.id)} aria-label={`Delete entry from ${it.source_host ?? it.provider}`}>
                  <Trash2 size={16} />
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
      {!compact && (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm">
            <button className="btn-ghost" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</button>
            <span className="text-slate-300">Page {page} of {pages}</span>
            <button className="btn-ghost" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>Next</button>
          </div>
          <button className="btn-danger" onClick={() => remove()}>Delete all history</button>
        </div>
      )}
    </div>
  );
}
