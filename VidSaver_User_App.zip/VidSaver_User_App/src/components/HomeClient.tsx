"use client";
import { useState } from "react";
import Link from "next/link";
import { Analyzer } from "./Analyzer";
import { HistoryList } from "./HistoryList";

export function HomeClient() {
  const [tick, setTick] = useState(0);
  return (
    <>
      <Analyzer onFinished={() => setTick((t) => t + 1)} />
      <section aria-labelledby="recent" className="card mt-6">
        <div className="mb-2 flex items-center justify-between">
          <h2 id="recent" className="text-lg font-bold">Recent downloads</h2>
          <Link href="/history" className="text-sm text-cyan-300 hover:underline">View all</Link>
        </div>
        <HistoryList compact refreshKey={tick} />
      </section>
    </>
  );
}
