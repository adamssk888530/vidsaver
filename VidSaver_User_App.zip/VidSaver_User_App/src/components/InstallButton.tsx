"use client";
import { useEffect, useRef, useState } from "react";
import { Download, X } from "lucide-react";
import { track } from "@/lib/analytics";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

/**
 * Install flow:
 *  - Chromium browsers fire `beforeinstallprompt`; we show the native prompt when the user clicks.
 *  - We only treat the app as installed when the browser reports it (`appinstalled` event or
 *    standalone display mode) — never merely because the button was clicked.
 *  - iOS Safari and some browsers expose no prompt, so we show Add-to-Home-Screen instructions.
 */
export function InstallButton() {
  const deferred = useRef<BeforeInstallPromptEvent | null>(null);
  const [canPrompt, setCanPrompt] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [help, setHelp] = useState(false);
  const [outcome, setOutcome] = useState<string | null>(null);

  useEffect(() => {
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (navigator as unknown as { standalone?: boolean }).standalone === true;
    setInstalled(standalone);

    const onPrompt = (e: Event) => {
      e.preventDefault();
      deferred.current = e as BeforeInstallPromptEvent;
      setCanPrompt(true);
    };
    const onInstalled = () => {
      setInstalled(true);
      setCanPrompt(false);
      track("app_installed");
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (installed) return null;

  const click = async () => {
    track("install_button_click");
    const ev = deferred.current;
    if (!ev) return setHelp(true);
    await ev.prompt();
    const choice = await ev.userChoice;
    deferred.current = null;
    setCanPrompt(false);
    if (choice.outcome === "accepted") {
      track("install_prompt_accepted");
      setOutcome("Your browser is installing VidSaver. It will appear on your device when it finishes.");
    } else {
      setOutcome("Install dismissed. You can try again any time.");
    }
    setHelp(true);
  };

  return (
    <>
      <button className="btn-ghost" onClick={click} aria-haspopup="dialog">
        <Download size={16} aria-hidden="true" />
        <span className="hidden sm:inline">Install App</span>
        <span className="sr-only sm:hidden">Install App</span>
      </button>
      {help && (
        <div role="dialog" aria-modal="true" aria-label="Install VidSaver" className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-4 sm:items-center">
          <div className="card w-full max-w-md">
            <div className="flex items-start justify-between gap-4">
              <h2 className="text-lg font-bold">Install VidSaver</h2>
              <button className="rounded-lg p-1 hover:bg-white/10" onClick={() => { setHelp(false); setOutcome(null); }} aria-label="Close">
                <X size={18} />
              </button>
            </div>
            {outcome ? (
              <p className="mt-3 text-sm text-slate-200">{outcome}</p>
            ) : (
              <div className="mt-3 space-y-3 text-sm text-slate-200">
                <p>
                  {canPrompt
                    ? "Use the browser's install prompt."
                    : "Your browser did not offer an automatic install prompt, so add it manually:"}
                </p>
                <ul className="list-disc space-y-1.5 pl-5">
                  <li><strong>iPhone / iPad (Safari):</strong> tap Share, then “Add to Home Screen”.</li>
                  <li><strong>Android (Chrome):</strong> open the ⋮ menu, then “Install app” or “Add to Home screen”.</li>
                  <li><strong>Desktop (Chrome / Edge):</strong> use the install icon in the address bar.</li>
                </ul>
                <p className="text-xs text-slate-400">
                  Installing requires HTTPS and a supported browser. Behaviour differs between devices, and
                  only your browser can confirm that installation succeeded.
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
