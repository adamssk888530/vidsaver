"use client";
import { useEffect } from "react";

/** Once per browser session, records last activity for signed-in users (powers the admin "active users" metric). */
export function SeenPing({ signedIn }: { signedIn: boolean }) {
  useEffect(() => {
    if (!signedIn) return;
    try {
      if (sessionStorage.getItem("vs_seen")) return;
      sessionStorage.setItem("vs_seen", "1");
    } catch {
      /* storage blocked: still ping once per page load */
    }
    fetch("/api/seen", { method: "POST", keepalive: true }).catch(() => {});
  }, [signedIn]);
  return null;
}
