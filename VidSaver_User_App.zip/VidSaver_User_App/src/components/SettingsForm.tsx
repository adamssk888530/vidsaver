"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import type { Profile } from "@/lib/types";

const CURRENCIES = ["NGN", "USD", "EUR", "GBP"];

export function SettingsForm({ profile }: { profile: Profile }) {
  const router = useRouter();
  const [name, setName] = useState(profile.display_name ?? "");
  const [currency, setCurrency] = useState(profile.preferred_currency);
  const [retention, setRetention] = useState(profile.history_retention_days);
  const [analytics, setAnalytics] = useState(profile.analytics_consent);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    const supabase = createClient();
    const { error } = await supabase
      .from("profiles")
      .update({
        display_name: name.trim().slice(0, 80) || null,
        preferred_currency: currency,
        history_retention_days: retention,
        analytics_consent: analytics,
      })
      .eq("id", profile.id);
    if (!error && analytics !== profile.analytics_consent) {
      await supabase.from("consent_records").insert({ user_id: profile.id, consent_type: "analytics", granted: analytics });
    }
    setBusy(false);
    setMsg(error ? { ok: false, text: "Could not save your settings. Please try again." } : { ok: true, text: "Settings saved." });
    if (!error) router.refresh();
  };

  const deleteAccount = async () => {
    if (!confirm("Permanently delete your account and all your data? This cannot be undone.")) return;
    const res = await fetch("/api/account", { method: "DELETE" });
    if (res.ok) {
      await createClient().auth.signOut();
      router.push("/");
      router.refresh();
    } else {
      setMsg({ ok: false, text: "Could not delete the account. Please contact support." });
    }
  };

  return (
    <div className="space-y-6">
      <form onSubmit={save} className="card space-y-4">
        <div>
          <label htmlFor="name" className="label">Display name</label>
          <input id="name" className="input" value={name} maxLength={80} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="cur" className="label">Currency</label>
            <select id="cur" className="input" value={currency} onChange={(e) => setCurrency(e.target.value)}>
              {CURRENCIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="ret" className="label">Keep history for</label>
            <select id="ret" className="input" value={retention} onChange={(e) => setRetention(Number(e.target.value))}>
              {[7, 30, 90, 180, 365].map((d) => <option key={d} value={d}>{d} days</option>)}
            </select>
          </div>
        </div>
        <label className="flex items-start gap-3 text-sm">
          <input type="checkbox" className="mt-1 accent-cyan-400" checked={analytics} onChange={(e) => setAnalytics(e.target.checked)} />
          <span>Allow anonymous usage analytics linked to my account. (Optional; you can change this at any time.)</span>
        </label>
        {msg && <div className={msg.ok ? "alert-ok" : "alert-error"} role="status">{msg.text}</div>}
        <button className="btn-primary" disabled={busy}>{busy && <Loader2 size={16} className="animate-spin" />} Save changes</button>
      </form>

      <section className="card border-red-400/30">
        <h2 className="text-lg font-bold">Delete account</h2>
        <p className="mt-1 text-sm text-slate-300">Removes your profile, download history and sign-in. This cannot be undone.</p>
        <button className="btn-danger mt-3" onClick={deleteAccount}>Delete my account</button>
      </section>
    </div>
  );
}
