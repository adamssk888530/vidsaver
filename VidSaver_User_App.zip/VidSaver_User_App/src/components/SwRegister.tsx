"use client";
import { useEffect, useState } from "react";

/** Registers the service worker (production only) and offers an explicit update prompt. */
export function SwRegister() {
  const [waiting, setWaiting] = useState<ServiceWorker | null>(null);

  useEffect(() => {
    if (!("serviceWorker" in navigator) || process.env.NODE_ENV !== "production") return;
    let reloaded = false;
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (reloaded) return;
      reloaded = true;
      window.location.reload();
    });
    navigator.serviceWorker
      .register("/sw.js")
      .then((reg) => {
        if (reg.waiting) setWaiting(reg.waiting);
        reg.addEventListener("updatefound", () => {
          const nw = reg.installing;
          nw?.addEventListener("statechange", () => {
            if (nw.state === "installed" && navigator.serviceWorker.controller) setWaiting(nw);
          });
        });
      })
      .catch(() => {});
  }, []);

  if (!waiting) return null;
  return (
    <div role="status" className="fixed inset-x-4 bottom-20 z-50 mx-auto max-w-md rounded-xl border border-cyan-400/40 bg-navy-800 p-4 shadow-glow md:bottom-6">
      <p className="text-sm">A new version of VidSaver is ready.</p>
      <button className="btn-primary mt-2" onClick={() => waiting.postMessage({ type: "SKIP_WAITING" })}>
        Update now
      </button>
    </div>
  );
}
