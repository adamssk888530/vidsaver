"use client";
import type { AnalyticsEventType } from "@/lib/types";

export function hasAnalyticsConsent(): boolean {
  return typeof document !== "undefined" && document.cookie.split("; ").includes("vs_consent=analytics");
}

/** Fire-and-forget. The server independently re-checks the consent cookie. */
export function track(type: AnalyticsEventType, path?: string) {
  if (!hasAnalyticsConsent()) return;
  fetch("/api/events", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type, path: path ?? window.location.pathname }),
    keepalive: true,
  }).catch(() => {});
}
