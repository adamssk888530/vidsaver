/** Maps Supabase auth errors to friendly, non-leaking messages. */
export function authMessage(err: { message?: string; code?: string; status?: number } | null): string {
  if (!err) return "Something went wrong. Please try again.";
  const m = (err.message ?? "").toLowerCase();
  if (m.includes("invalid login") || err.code === "invalid_credentials") return "Incorrect email or password.";
  if (m.includes("email not confirmed")) return "Please confirm your email first — check your inbox for the link.";
  if (m.includes("already registered") || err.code === "user_already_exists") return "An account with this email already exists. Try signing in instead.";
  if (m.includes("password") && (m.includes("short") || m.includes("least") || m.includes("weak"))) return "Choose a stronger password (at least 8 characters).";
  if (err.status === 429 || m.includes("rate limit") || m.includes("too many")) return "Too many attempts. Please wait a few minutes and try again.";
  if (m.includes("fetch") || m.includes("network")) return "Network error. Check your connection and try again.";
  return "We couldn't complete that request. Please try again.";
}
