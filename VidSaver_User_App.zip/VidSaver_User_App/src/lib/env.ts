import { z } from "zod";

const publicSchema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(20),
  NEXT_PUBLIC_SITE_URL: z.string().url().default("http://localhost:3000"),
});

const serverSchema = z.object({
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(20).optional(),
  DOWNLOAD_TOKEN_SECRET: z.string().min(32, "DOWNLOAD_TOKEN_SECRET must be at least 32 characters"),
  ENABLE_DEMO_PROVIDER: z.enum(["true", "false"]).default("true"),
});

export function publicEnv() {
  // NEXT_PUBLIC_* must be referenced literally so Next can inline them in the browser bundle.
  const parsed = publicSchema.safeParse({
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL,
  });
  if (!parsed.success) {
    throw new Error(
      "Invalid public environment variables: " + parsed.error.issues.map((i) => i.path.join(".")).join(", ")
    );
  }
  return parsed.data;
}

let cachedServer: z.infer<typeof serverSchema> | null = null;
/** Server-only. Throws a generic error (no secret values) if misconfigured. */
export function serverEnv() {
  if (typeof window !== "undefined") throw new Error("serverEnv() must not be called in the browser");
  if (cachedServer) return cachedServer;
  const parsed = serverSchema.safeParse(process.env);
  if (!parsed.success) {
    throw new Error(
      "Invalid server environment variables: " + parsed.error.issues.map((i) => i.path.join(".")).join(", ")
    );
  }
  cachedServer = parsed.data;
  return cachedServer;
}
