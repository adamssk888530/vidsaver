import "server-only";
import { createHash } from "node:crypto";
import type { SupabaseClient, User } from "@supabase/supabase-js";
import { createAdminClient } from "@/lib/supabase/admin";
import type { JobStatus } from "@/lib/types";

export function hashUrl(url: URL): string {
  const u = new URL(url.href);
  u.hash = "";
  return createHash("sha256").update(u.href).digest("hex");
}

/** Safe, short, non-sensitive message to store on failures. */
export function safeMessage(msg: string): string {
  return msg.replace(/https?:\/\/\S+/g, "[url]").slice(0, 280);
}

/**
 * Signed-in users write through their own session (RLS enforced).
 * Guests write through the server-only service-role client, which exists solely for this and
 * returns null when not configured (guest history is then simply not recorded).
 */
function writer(userClient: SupabaseClient, user: User | null) {
  return user ? userClient : createAdminClient();
}

export async function createJob(
  userClient: SupabaseClient,
  user: User | null,
  anonId: string | null,
  fields: {
    provider: string;
    source_host: string;
    source_hash: string;
    format?: string | null;
    quality?: string | null;
    status: JobStatus;
    error_code?: string;
    error_message?: string;
  }
): Promise<string | null> {
  const db = writer(userClient, user);
  if (!db) return null;
  const { data, error } = await db
    .from("download_jobs")
    .insert({
      ...fields,
      user_id: user?.id ?? null,
      anon_session_id: user ? null : anonId,
    })
    .select("id")
    .single();
  if (error) return null; // history is best-effort; never block the user on logging
  return data.id as string;
}

export async function updateJob(
  userClient: SupabaseClient,
  user: User | null,
  jobId: string | null,
  patch: Partial<{
    status: JobStatus;
    format: string;
    quality: string;
    bytes: number;
    error_code: string;
    error_message: string;
    completed_at: string;
  }>
) {
  if (!jobId) return;
  const db = writer(userClient, user);
  if (!db) return;
  let q = db.from("download_jobs").update(patch).eq("id", jobId);
  q = user ? q.eq("user_id", user.id) : q.is("user_id", null);
  await q;
}
