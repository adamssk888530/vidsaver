import "server-only";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { ProviderError, type ProviderAdapter } from "./types";

/**
 * DEMO PROVIDER — demonstrates the adapter interface only.
 * It serves one bundled, original test clip (generated test pattern + sine tone, no third-party content).
 * It makes NO outbound requests, so there is no SSRF surface.
 *
 * Try it with:  https://demo.vidsaver.example/sample-1
 * (".example" is a reserved TLD and never resolves on the public internet.)
 */
const DEMO_HOST = "demo.vidsaver.example";
const ITEMS: Record<string, { title: string; file: string; durationSec: number }> = {
  "sample-1": { title: "VidSaver demo clip (test pattern, 5s)", file: "sample-1.mp4", durationSec: 5 },
};

const filePath = (file: string) => path.join(process.cwd(), "assets", "demo", file);

export const demoProvider: ProviderAdapter = {
  id: "demo",
  displayName: "Demo Provider (sample media)",
  mode: "demo",
  supportsAudioOnly: false,

  matches(url) {
    return url.hostname.toLowerCase() === DEMO_HOST;
  },

  async analyze(url) {
    const itemId = url.pathname.replace(/^\/+|\/+$/g, "");
    const item = ITEMS[itemId];
    if (!item) throw new ProviderError("not_found", "No demo item at that path. Try /sample-1.");
    const size = (await stat(filePath(item.file))).size;
    return {
      itemId,
      title: item.title,
      durationSec: item.durationSec,
      thumbnailUrl: null,
      previewAllowed: true,
      formats: [
        { id: "mp4-360p", label: "MP4 · 360p", kind: "video", container: "mp4", quality: "360p", approxBytes: size },
      ],
    };
  },

  async open(itemId, formatId) {
    const item = ITEMS[itemId];
    if (!item) throw new ProviderError("not_found", "Item not found");
    if (formatId !== "mp4-360p") throw new ProviderError("format_unavailable", "That format is not available");
    const p = filePath(item.file);
    const size = (await stat(p)).size;
    return {
      stream: Readable.toWeb(createReadStream(p)) as ReadableStream<Uint8Array>,
      contentType: "video/mp4",
      contentLength: size,
      filename: "vidsaver-demo-sample.mp4",
    };
  },
};
