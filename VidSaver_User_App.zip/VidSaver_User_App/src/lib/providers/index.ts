import "server-only";
import { demoProvider } from "./demo";
import type { ProviderAdapter } from "./types";

/**
 * Registry of EXPLICITLY supported providers.
 * To add a lawful, authorized source: create src/lib/providers/<name>.ts implementing
 * ProviderAdapter, import it here, and add a row to public.provider_configs.
 * A URL whose host no adapter matches is rejected as "unsupported" — there is no fallback fetcher.
 */
function registry(): ProviderAdapter[] {
  const list: ProviderAdapter[] = [];
  if (process.env.ENABLE_DEMO_PROVIDER !== "false") list.push(demoProvider);
  return list;
}

export function findProvider(url: URL): ProviderAdapter | null {
  return registry().find((p) => p.matches(url)) ?? null;
}

export function getProviderById(id: string): ProviderAdapter | null {
  return registry().find((p) => p.id === id) ?? null;
}

export function listProviders() {
  return registry().map((p) => ({ id: p.id, name: p.displayName, mode: p.mode, audioOnly: p.supportsAudioOnly }));
}
