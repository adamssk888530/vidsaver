import type { MediaFormat } from "@/lib/types";

export interface AnalyzeResult {
  itemId: string;
  title: string;
  durationSec?: number;
  thumbnailUrl?: string | null;
  /** Only true where the rights holder / platform terms permit embedding a preview. */
  previewAllowed: boolean;
  formats: MediaFormat[];
}

export interface OpenedMedia {
  stream: ReadableStream<Uint8Array>;
  contentType: string;
  /** Real size when known. Never guessed. */
  contentLength?: number;
  filename: string;
}

/**
 * A provider adapter is the ONLY place that talks to a media source.
 * Rules for adapters:
 *  - Only handle sources you are authorized to access (own content, licensed API, public-domain, etc.).
 *  - Never bypass DRM, authentication, paywalls, privacy settings or platform restrictions.
 *  - Any outbound fetch must pass `assertPublicHost()` from urlguard.ts.
 *  - Return real metadata only. Throw ProviderError for anything you cannot do.
 */
export interface ProviderAdapter {
  id: string;
  displayName: string;
  mode: "demo" | "production";
  supportsAudioOnly: boolean;
  /** Called with an already-validated https URL. Must be a pure host/path match. */
  matches(url: URL): boolean;
  analyze(url: URL): Promise<AnalyzeResult>;
  open(itemId: string, formatId: string): Promise<OpenedMedia>;
}

export class ProviderError extends Error {
  constructor(
    public code: "not_found" | "private_or_restricted" | "unavailable" | "format_unavailable",
    message: string
  ) {
    super(message);
  }
}
