import "server-only";

/**
 * Rate-limiting architecture.
 * Default: in-memory sliding window (per server instance). This is fine for local dev and a single
 * long-lived server, but on serverless hosts (Vercel) each instance has its own memory, so limits are
 * best-effort only. For production, implement `RateLimiter` against a shared store (Upstash Redis,
 * Vercel KV, Supabase table) and swap it in `limiter` below — call sites do not change.
 */
export interface RateLimiter {
  check(key: string, limit: number, windowMs: number): Promise<{ allowed: boolean; retryAfterSec: number }>;
}

class MemoryLimiter implements RateLimiter {
  private hits = new Map<string, number[]>();
  async check(key: string, limit: number, windowMs: number) {
    const now = Date.now();
    const arr = (this.hits.get(key) ?? []).filter((t) => now - t < windowMs);
    if (arr.length >= limit) {
      this.hits.set(key, arr);
      return { allowed: false, retryAfterSec: Math.max(1, Math.ceil((windowMs - (now - arr[0])) / 1000)) };
    }
    arr.push(now);
    this.hits.set(key, arr);
    if (this.hits.size > 5000) {
      for (const [k, v] of this.hits) if (v.every((t) => now - t >= windowMs)) this.hits.delete(k);
    }
    return { allowed: true, retryAfterSec: 0 };
  }
}

export const limiter: RateLimiter = new MemoryLimiter();

export function clientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  return (fwd?.split(",")[0] ?? req.headers.get("x-real-ip") ?? "unknown").trim().slice(0, 64);
}
