import "server-only";
import { randomUUID } from "node:crypto";
import { cookies } from "next/headers";

const COOKIE = "vs_anon";

/** Returns the guest session id, creating a first-party, httpOnly, random identifier if absent. */
export async function getOrCreateAnonId(): Promise<string> {
  const store = await cookies();
  const existing = store.get(COOKIE)?.value;
  if (existing && /^[0-9a-f-]{36}$/.test(existing)) return existing;
  const id = randomUUID();
  store.set(COOKIE, id, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
  return id;
}

export async function readAnonId(): Promise<string | null> {
  const v = (await cookies()).get(COOKIE)?.value;
  return v && /^[0-9a-f-]{36}$/.test(v) ? v : null;
}
