import "server-only";
import { createClient } from "@supabase/supabase-js";

/**
 * SERVER-ONLY service-role client (bypasses RLS).
 * Used exclusively for: guest job records and consent-gated analytics inserts.
 * Returns null when SUPABASE_SERVICE_ROLE_KEY is not configured.
 * Never import this from a client component.
 */
export function createAdminClient() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!key || !url) return null;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}
