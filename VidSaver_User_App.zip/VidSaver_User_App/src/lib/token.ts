import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";
import { serverEnv } from "@/lib/env";

export interface DownloadClaims {
  j: string | null; // job id
  p: string; // provider id
  i: string; // provider item id
  u: string | null; // user id (null for guests)
  a: string | null; // anon session id (guests)
  e: number; // expiry (unix seconds)
}

const b64 = (b: Buffer) => b.toString("base64url");

export function signToken(claims: Omit<DownloadClaims, "e">, ttlSec = 15 * 60): string {
  const body = b64(Buffer.from(JSON.stringify({ ...claims, e: Math.floor(Date.now() / 1000) + ttlSec })));
  const sig = b64(createHmac("sha256", serverEnv().DOWNLOAD_TOKEN_SECRET).update(body).digest());
  return `${body}.${sig}`;
}

export function verifyToken(token: string): DownloadClaims | null {
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = createHmac("sha256", serverEnv().DOWNLOAD_TOKEN_SECRET).update(body).digest();
  let given: Buffer;
  try {
    given = Buffer.from(sig, "base64url");
  } catch {
    return null;
  }
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return null;
  try {
    const claims = JSON.parse(Buffer.from(body, "base64url").toString()) as DownloadClaims;
    if (typeof claims.e !== "number" || claims.e < Date.now() / 1000) return null;
    return claims;
  } catch {
    return null;
  }
}
