import "server-only";
import { lookup } from "node:dns/promises";
import { isIP } from "node:net";

export class UrlRejected extends Error {
  constructor(public reason: string) {
    super(reason);
  }
}

const MAX_URL_LENGTH = 2048;

/**
 * Step 1 — syntactic validation. Accepts only plain https URLs on the default port,
 * without credentials, and never an IP literal or local hostname.
 */
export function parseUserUrl(raw: unknown): URL {
  if (typeof raw !== "string") throw new UrlRejected("URL must be a string");
  const trimmed = raw.trim();
  if (!trimmed || trimmed.length > MAX_URL_LENGTH) throw new UrlRejected("URL is empty or too long");
  if (/[\u0000-\u001f\u007f\s]/.test(trimmed)) throw new UrlRejected("URL contains illegal characters");

  let url: URL;
  try {
    url = new URL(trimmed);
  } catch {
    throw new UrlRejected("Not a valid URL");
  }
  if (url.protocol !== "https:") throw new UrlRejected("Only https:// links are accepted");
  if (url.username || url.password) throw new UrlRejected("URLs with credentials are not accepted");
  if (url.port && url.port !== "443") throw new UrlRejected("Non-standard ports are not accepted");

  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  if (isIP(host) || host.startsWith("[")) throw new UrlRejected("IP-address URLs are not accepted");
  if (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local") ||
    host.endsWith(".internal") ||
    !host.includes(".")
  ) {
    throw new UrlRejected("Local and internal hostnames are not accepted");
  }
  return url;
}

export function isPrivateIp(ip: string): boolean {
  const v = isIP(ip);
  if (v === 4) {
    const [a, b] = ip.split(".").map(Number);
    return (
      a === 0 || a === 10 || a === 127 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 192 && b === 0) ||
      a >= 224
    );
  }
  if (v === 6) {
    const x = ip.toLowerCase();
    if (x === "::1" || x === "::") return true;
    if (x.startsWith("fc") || x.startsWith("fd") || x.startsWith("fe8") || x.startsWith("fe9") || x.startsWith("fea") || x.startsWith("feb")) return true;
    if (x.startsWith("::ffff:")) return isPrivateIp(x.slice(7));
    return false;
  }
  return true; // not an IP at all -> treat as unsafe
}

/**
 * Step 2 — for provider adapters that make outbound requests: resolve DNS and refuse
 * any host that maps to a private, loopback, link-local or reserved address.
 * Real adapters MUST call this and then connect to the resolved address (or use a
 * fetch agent that re-validates) to avoid DNS-rebinding between check and use.
 * The bundled demo adapter performs no outbound requests and does not need it.
 */
export async function assertPublicHost(hostname: string): Promise<void> {
  const records = await lookup(hostname, { all: true, verbatim: true });
  if (!records.length) throw new UrlRejected("Host did not resolve");
  for (const r of records) {
    if (isPrivateIp(r.address)) throw new UrlRejected("Host resolves to a non-public address");
  }
}
